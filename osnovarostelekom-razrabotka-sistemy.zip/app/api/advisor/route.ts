import { generateText, gateway } from 'ai'
import { NextResponse } from 'next/server'

type Company = Record<string, unknown>

type CalculatedCompany = Company & {
  budgetMillions: number
  marginPercent: number
  annualProfitMillions: number
  paybackMonths: number | null
}

const numberValue = (value: unknown) => {
  const source = String(value ?? '').toLowerCase().replace(',', '.')
  const number = Number(source.replace(/[^0-9.]/g, ''))
  return Number.isFinite(number) ? number * (source.includes('млрд') ? 1000 : 1) : 0
}

const calculate = (company: Company): CalculatedCompany => {
  const budgetMillions = numberValue(company.budget)
  const marginPercent = numberValue(company.margin)
  const annualProfitMillions = budgetMillions * marginPercent / 100
  return { ...company, budgetMillions, marginPercent, annualProfitMillions, paybackMonths: annualProfitMillions > 0 ? budgetMillions / annualProfitMillions * 12 : null }
}

const money = (value: number) => `${value.toFixed(1)} млн ₽`

export async function POST(request: Request) {
  try {
    const { companies, question } = await request.json() as { companies?: Company[]; question?: string }
    if (!Array.isArray(companies) || companies.length < 2) {
      return NextResponse.json({ error: 'Нужно выбрать минимум две компании для сравнения.' }, { status: 400 })
    }

    const results = companies.map(calculate)
    const bestPayback = [...results].filter(item => item.paybackMonths !== null).sort((a, b) => (a.paybackMonths ?? Infinity) - (b.paybackMonths ?? Infinity))[0]
    const bestMargin = [...results].sort((a, b) => b.marginPercent - a.marginPercent)[0]
    const bestPotential = [...results].sort((a, b) => Number(b.potential ?? 0) - Number(a.potential ?? 0))[0]
    const winner = bestPayback ?? bestMargin
    const questionType = /маржин|прибыл|процент/i.test(question ?? '') ? 'margin' : /спрос|востреб|регион/i.test(question ?? '') ? 'demand' : /риск|сорвать|провер/i.test(question ?? '') ? 'risk' : /30 дней|запуст/i.test(question ?? '') ? 'speed' : 'payback'
    const selected = questionType === 'margin' ? bestMargin : questionType === 'demand' ? bestPotential : winner
    const comparison = results.map(item => `• ${item.name} (${item.region}): бюджет ${money(item.budgetMillions)}, маржа ${item.marginPercent.toFixed(1)}%, годовая прибыль ${money(item.annualProfitMillions)}, окупаемость ${item.paybackMonths === null ? 'нет данных' : `${item.paybackMonths.toFixed(1)} мес.`}, потенциал ${item.potential ?? 'нет данных'}/100`).join('\n')
    const conclusions = {
      payback: `Выбран проект с минимальным сроком окупаемости — ${selected?.name}. Это рациональный вариант для первого запуска и ограничения срока возврата вложений.`,
      margin: `Выбран проект с максимальной маржинальностью — ${selected?.name}. Он создаёт больший запас валовой прибыли, но требует проверки фактической себестоимости и цены контракта.`,
      demand: `Выбран проект с максимальным потенциалом — ${selected?.name}. Его целесообразно рассматривать как платформу роста, если региональный спрос подтвердится пилотом.`,
      risk: `Для снижения риска выбран наиболее сбалансированный проект — ${selected?.name}: его решение опирается на лучшее сочетание окупаемости и экономического потенциала.`,
      speed: `Для запуска за короткий срок выбран проект — ${selected?.name}. Приоритетом должны стать готовая инфраструктура, типовое решение и согласованный бюджет.`
    }[questionType]
    const text = `## Вывод советника\n\n**Рекомендация:** ${conclusions}\n\n### Ответ на вопрос\n${question || 'Какой проект выгоднее и быстрее окупится?'}\n\n${comparison}\n\n### Математическое обоснование\n• Маржинальность: ${selected?.marginPercent.toFixed(1) ?? 'нет данных'}%.\n• Расчётная годовая прибыль: ${selected ? money(selected.annualProfitMillions) : 'нет данных'}.\n• Срок окупаемости: ${selected?.paybackMonths === null ? 'нет данных' : `${selected?.paybackMonths.toFixed(1)} месяца`}.\n• Бюджет: ${selected ? money(selected.budgetMillions) : 'нет данных'}.\n\n### Практический совет\nНачать с пилота на одном объекте, зафиксировать бюджет и срок, затем проверить фактическую маржу по этапам: оборудование, работы, ПО и сопровождение. Логика выбора изменяется в зависимости от вопроса: окупаемость — минимальный срок, маржинальность — максимальная прибыльность, спрос — потенциал, риск — баланс показателей, скорость — готовность запуска.\n\n### Важно проверить до вложений\n1. Подтверждённый бюджет и источник финансирования.\n2. Реальный срок реализации и готовность инфраструктуры.\n3. Стоимость оборудования, работ и ПО.\n4. Конкурентов и наличие действующих контрактов.\n5. Фактический спрос и возможность масштабирования.\n\n*Расчёт детерминированный: годовая прибыль = бюджет × маржинальность / 100; окупаемость = бюджет / годовая прибыль × 12. Это аналитическая оценка, а не финансовая гарантия.*`
    let aiText = text
    try {
      const generated = await generateText({
        model: gateway('deepseek/deepseek-v4.1-flash'),
        temperature: 0.65,
        maxOutputTokens: 1200,
        system: 'Ты официальный аналитический советник ПАО «Ростелеком». Каждый запрос анализируй заново по переданным данным. Не копируй шаблонный вывод и не меняй числа. Сначала определи, что именно спрашивается, затем сравни показатели, объясни компромиссы, назови риски и дай конкретное решение. Пиши на русском официальным деловым стилем, без markdown-решёток, эмодзи и общих фраз.',
        prompt: `Вопрос пользователя: ${question || 'Какой проект выбрать первым?'}\n\nРезультаты расчёта по компаниям:\n${JSON.stringify(results, null, 2)}\n\nСформируй самостоятельный вывод именно для этого вопроса. Укажи выбранную компанию, числовое обоснование, отличие от альтернатив и три практических действия.`,
      })
      if (generated.text.trim()) aiText = `${generated.text.trim()}\n\nМатематическая база расчёта:\n${text}`
    } catch (error) {
      console.error('[v0] advisor AI fallback', error)
    }
    return NextResponse.json({ text: aiText, calculated: results, aiGenerated: aiText !== text })
  } catch {
    return NextResponse.json({ error: 'Не удалось выполнить расчёт. Проверьте выбранные компании.' }, { status: 400 })
  }
}
