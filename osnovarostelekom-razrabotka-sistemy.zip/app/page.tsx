import { RostelecomDashboard } from '@/components/rostelecom-dashboard'

export default function Page() {
  return <RostelecomDashboard />
}
