'use client'

import { useEffect, useMemo, useState } from 'react'
import { read, utils, write } from 'xlsx'
import { LeafletPresenceMap } from './leaflet-presence-map'
import {
  Activity,
  Bell,
  BriefcaseBusiness,
  Building2,
  Calculator,
  ChevronDown,
  CircleHelp,
  Download,
  FileText,
  Grid2X2,
  LayoutDashboard,
  Map,
  Menu,
  Search,
  ShieldCheck,
  Settings,
  Sparkles,
  Target,
  TrendingUp,
  Users,
  X,
} from 'lucide-react'

type Module = 'overview' | 'radar' | 'companies' | 'navigator' | 'calculator' | 'compare' | 'create' | 'profile'
type HistoryItem = { id: string; action: string; detail: string; time: string }
type ExportItem = { id: string; fileName: string; title: string; rows: number; createdAt: string }
type CompanyRecord = { name: string; inn: string; industry: string; region: string; status: string; potential: number; revenue: string; revenueMillions: number; growth: string; need: string; budget: string; direction: string; goal: string; margin: string }

// Демонстрационный слой на основе открытых карточек компаний ФНС/ЕГРЮЛ; финансовые оценки помечены как расчетные.
const companies = [
  { name: 'ПАО «Ростелеком»', inn: '7707049388', industry: 'Телеком', region: 'Ростовская область', status: 'Действующий', potential: 94, revenue: 'крупная', revenueMillions: 10000, growth: '+12,4%', need: 'Цифровая инфраструктура', budget: '4,8 млрд ₽', direction: 'Связь и ИТ', goal: 'Модернизация сетей', margin: '28%' },
  { name: 'ПАО «НК «Роснефть»', inn: '7706107510', industry: 'Энергетика', region: 'Краснодарский край', status: 'Потенциальный', potential: 91, revenue: 'крупная', revenueMillions: 10000, growth: '+16,8%', need: 'Промышленный IoT', budget: '3,2 млрд ₽', direction: 'Топливно-энергетический комплекс', goal: 'Цифровизация активов', margin: '24%' },
  { name: 'АО «Тандер»', inn: '2310031475', industry: 'Ритейл', region: 'Краснодарский край', status: 'Потенциальный', potential: 89, revenue: 'крупная', revenueMillions: 10000, growth: '+11,7%', need: 'Корпоративная сеть', budget: '1,9 млрд ₽', direction: 'Розничная торговля', goal: 'Омниканальная логистика', margin: '22%' },
  { name: 'ПАО «Новороссийский морской торговый порт»', inn: '2315004408', industry: 'Логистика', region: 'Краснодарский край', status: 'Потенциальный', potential: 88, revenue: 'крупная', revenueMillions: 10000, growth: '+14,2%', need: 'Безопасность и ЦОД', budget: '1,4 млрд ₽', direction: 'Портовая инфраструктура', goal: 'Автоматизация терминалов', margin: '26%' },
  { name: 'ПАО «Донской завод»', inn: '6163010010', industry: 'Промышленность', region: 'Ростовская область', status: 'Потенциальный', potential: 84, revenue: 'крупная', revenueMillions: 2400, growth: '+9,8%', need: 'АСУ ТП', budget: '860 млн ₽', direction: 'Машиностроение', goal: 'Рост производительности', margin: '19%' },
  { name: 'ПАО «Волгограднефтемаш»', inn: '3444010890', industry: 'Промышленность', region: 'Волгоградская область', status: 'Потенциальный', potential: 82, revenue: 'крупная', revenueMillions: 1800, growth: '+8,6%', need: 'Защищенная сеть', budget: '720 млн ₽', direction: 'Машиностроение', goal: 'Импортозамещение', margin: '21%' },
  { name: 'ООО «Астраханское судостроительное объединение»', inn: '3015015470', industry: 'Промышленность', region: 'Астраханская область', status: 'Потенциальный', potential: 79, revenue: 'крупная', revenueMillions: 1200, growth: '+13,1%', need: 'Видеонаблюдение', budget: '410 млн ₽', direction: 'Судостроение', goal: 'Расширение мощностей', margin: '18%' },
  { name: 'АО «Каспийский завод листового стекла»', inn: '0816010012', industry: 'Промышленность', region: 'Республика Калмыкия', status: 'Не определён', potential: 76, revenue: 'крупная', revenueMillions: 1100, growth: '+7,9%', need: 'Мониторинг производства', budget: '350 млн ₽', direction: 'Производство материалов', goal: 'Снижение простоев', margin: '17%' },
  { name: 'ООО «Агрокомплекс Юг»', inn: '2309123456', industry: 'АПК', region: 'Краснодарский край', status: 'Потенциальный', potential: 74, revenue: 'средняя', revenueMillions: 640, growth: '+10,2%', need: 'Умное сельское хозяйство', budget: '96 млн ₽', direction: 'Агропромышленный комплекс', goal: 'Автоматизация полей', margin: '16%' },
  { name: 'ИП «КубаньЛогистик»', inn: '616412345678', industry: 'Логистика', region: 'Ростовская область', status: 'Потенциальный', potential: 71, revenue: 'малая', revenueMillions: 180, growth: '+18,4%', need: 'Облачная телефония', budget: '18 млн ₽', direction: 'Грузовые перевозки', goal: 'Масштабирование бизнеса', margin: '14%' },
  { name: 'ООО «Волгоградские тепловые системы»', inn: '3445123456', industry: 'Энергетика', region: 'Волгоградская область', status: 'Потенциальный', potential: 69, revenue: 'средняя', revenueMillions: 420, growth: '+6,8%', need: 'Мониторинг объектов', budget: '54 млн ₽', direction: 'Коммунальная инфраструктура', goal: 'Снижение потерь', margin: '15%' },
  { name: 'ИП «Астрахань Рыба»', inn: '301712345678', industry: 'Промышленность', region: 'Астраханская область', status: 'Потенциальный', potential: 66, revenue: 'малая', revenueMillions: 95, growth: '+12,1%', need: 'Защищенный интернет', budget: '8 млн ₽', direction: 'Переработка продуктов', goal: 'Выход на новые рынки', margin: '13%' },
  { name: 'ООО «Севастополь Марин»', inn: '9204123456', industry: 'Логистика', region: 'г. Севастополь', status: 'Потенциальный', potential: 64, revenue: 'средняя', revenueMillions: 310, growth: '+9,3%', need: 'Корпоративная сеть', budget: '37 млн ₽', direction: 'Морская логистика', goal: 'Цифровизация флота', margin: '18%' },
  { name: 'ООО «Донской фермер»', inn: '6165123456', industry: 'АПК', region: 'Ростовская область', status: 'Потенциальный', potential: 62, revenue: 'малая', revenueMillions: 72, growth: '+15,6%', need: 'Видеонаблюдение', budget: '6 млн ₽', direction: 'Растениеводство', goal: 'Контроль урожайности', margin: '12%' },
  { name: 'ООО «КрымЭкоТур»', inn: '9109123456', industry: 'Ритейл', region: 'Республика Крым', status: 'Потенциальный', potential: 60, revenue: 'средняя', revenueMillions: 260, growth: '+11,5%', need: 'Wi-Fi для бизнеса', budget: '24 млн ₽', direction: 'Туризм и гостеприимство', goal: 'Рост клиентского сервиса', margin: '20%' },
  { name: 'ИП «Адыгея Сервис»', inn: '010612345678', industry: 'Ритейл', region: 'Республика Адыгея', status: 'Потенциальный', potential: 58, revenue: 'малая', revenueMillions: 48, growth: '+8,9%', need: 'Онлайн-кассы и связь', budget: '4 млн ₽', direction: 'Сервисные услуги', goal: 'Открытие филиалов', margin: '11%' },
  { name: 'АО «Ростовский электрометаллургический завод»', inn: '6164267890', industry: 'Промышленность', region: 'Ростовская область', status: 'Потенциальный', potential: 87, revenue: 'крупная', revenueMillions: 3200, growth: '+10,8%', need: 'Промышленный интернет', budget: '1,1 млрд ₽', direction: 'Металлургия', goal: 'Модернизация производства', margin: '23%' },
  { name: 'ООО «Ростсельмаш»', inn: '6163075503', industry: 'Промышленность', region: 'Ростовская область', status: 'Потенциальный', potential: 86, revenue: 'крупная', revenueMillions: 5400, growth: '+14,7%', need: 'Цифровой завод', budget: '1,8 млрд ₽', direction: 'Сельхозмашиностроение', goal: 'Масштабирование мощностей', margin: '25%' },
  { name: 'АО «Кубаньэнерго»', inn: '2309001660', industry: 'Энергетика', region: 'Краснодарский край', status: 'Потенциальный', potential: 85, revenue: 'крупная', revenueMillions: 4600, growth: '+9,6%', need: 'Мониторинг сетей', budget: '1,3 млрд ₽', direction: 'Электроэнергетика', goal: 'Повышение надежности сетей', margin: '21%' },
  { name: 'ООО «Черномортранснефть»', inn: '2315033435', industry: 'Логистика', region: 'Краснодарский край', status: 'Потенциальный', potential: 83, revenue: 'крупная', revenueMillions: 2800, growth: '+12,9%', need: 'Защищенная связь', budget: '980 млн ₽', direction: 'Трубопроводный транспорт', goal: 'Безопасность инфраструктуры', margin: '20%' },
  { name: 'ПАО «Волгоградский нефтеперерабатывающий завод»', inn: '3444102030', industry: 'Промышленность', region: 'Волгоградская область', status: 'Потенциальный', potential: 81, revenue: 'крупная', revenueMillions: 4100, growth: '+8,2%', need: 'АСУ ТП и ЦОД', budget: '1,5 млрд ₽', direction: 'Нефтепереработка', goal: 'Оптимизация производственных циклов', margin: '22%' },
  { name: 'АО «Волгоградский тракторный завод»', inn: '3444001234', industry: 'Промышленность', region: 'Волгоградская область', status: 'Потенциальный', potential: 78, revenue: 'крупная', revenueMillions: 1750, growth: '+7,4%', need: 'Корпоративная сеть', budget: '530 млн ₽', direction: 'Машиностроение', goal: 'Импортозамещение', margin: '18%' },
  { name: 'ООО «Астраханский порт»', inn: '3015002784', industry: 'Логистика', region: 'Астраханская область', status: 'Потенциальный', potential: 77, revenue: 'крупная', revenueMillions: 1320, growth: '+11,3%', need: 'Умный порт', budget: '390 млн ₽', direction: 'Портовая логистика', goal: 'Увеличение грузооборота', margin: '19%' },
  { name: 'АО «Астраханская судостроительная компания»', inn: '3015017621', industry: 'Промышленность', region: 'Астраханская область', status: 'Потенциальный', potential: 75, revenue: 'крупная', revenueMillions: 1080, growth: '+9,1%', need: 'Видеонаблюдение и связь', budget: '330 млн ₽', direction: 'Судостроение', goal: 'Расширение производственной линии', margin: '17%' },
  { name: 'ООО «ЮгАгроХолдинг»', inn: '2311123450', industry: 'АПК', region: 'Краснодарский край', status: 'Потенциальный', potential: 73, revenue: 'средняя', revenueMillions: 890, growth: '+13,8%', need: 'IoT для полей', budget: '140 млн ₽', direction: 'Агропромышленный комплекс', goal: 'Рост урожайности', margin: '18%' },
  { name: 'ООО «Донские зерновые терминалы»', inn: '6167123450', industry: 'АПК', region: 'Ростовская область', status: 'Потенциальный', potential: 72, revenue: 'средняя', revenueMillions: 760, growth: '+12,6%', need: 'Автоматизация элеватора', budget: '115 млн ₽', direction: 'Хранение и экспорт зерна', goal: 'Увеличение пропускной способности', margin: '16%' },
  { name: 'ООО «Южный IT-кластер»', inn: '6168123450', industry: 'Телеком', region: 'Ростовская область', status: 'Потенциальный', potential: 70, revenue: 'средняя', revenueMillions: 510, growth: '+22,1%', need: 'Облачные сервисы', budget: '68 млн ₽', direction: 'Разработка ПО', goal: 'Выход на федеральный рынок', margin: '27%' },
  { name: 'ИП «Кубань Техсервис»', inn: '231112345678', industry: 'Промышленность', region: 'Краснодарский край', status: 'Потенциальный', potential: 67, revenue: 'малая', revenueMillions: 120, growth: '+19,2%', need: 'Онлайн-кассы и интернет', budget: '12 млн ₽', direction: 'Ремонт оборудования', goal: 'Открытие сервисных точек', margin: '15%' },
  { name: 'ИП «Донская доставка»', inn: '616812345679', industry: 'Логистика', region: 'Ростовская область', status: 'Потенциальный', potential: 65, revenue: 'малая', revenueMillions: 86, growth: '+17,4%', need: 'Трекинг транспорта', budget: '9 млн ₽', direction: 'Курьерские услуги', goal: 'Расширение автопарка', margin: '13%' },
  { name: 'ООО «Каспий Фиш»', inn: '3017123451', industry: 'Промышленность', region: 'Астраханская область', status: 'Потенциальный', potential: 63, revenue: 'средняя', revenueMillions: 340, growth: '+10,5%', need: 'Защищенный интернет', budget: '42 млн ₽', direction: 'Рыбопереработка', goal: 'Увеличение экспорта', margin: '14%' },
  { name: 'ИП «Степной фермер»', inn: '081612345678', industry: 'АПК', region: 'Республика Калмыкия', status: 'Потенциальный', potential: 59, revenue: 'малая', revenueMillions: 64, growth: '+14,9%', need: 'Умное земледелие', budget: '7 млн ₽', direction: 'Животноводство', goal: 'Снижение затрат', margin: '12%' },
  { name: 'ООО «Адыгея Агро»', inn: '0107123450', industry: 'АПК', region: 'Республика Адыгея', status: 'Потенциальный', potential: 61, revenue: 'средняя', revenueMillions: 290, growth: '+11,9%', need: 'Связь на производстве', budget: '31 млн ₽', direction: 'Переработка зерна', goal: 'Рост объемов производства', margin: '15%' },
  { name: 'ООО «Севастопольский технопарк»', inn: '9204123450', industry: 'Телеком', region: 'г. Севастополь', status: 'Потенциальный', potential: 68, revenue: 'средняя', revenueMillions: 380, growth: '+20,4%', need: 'ЦОД и облако', budget: '58 млн ₽', direction: 'Технологическое предпринимательство', goal: 'Привлечение резидентов', margin: '24%' },
  { name: 'ИП «Крым Тур Сервис»', inn: '910912345678', industry: 'Ритейл', region: 'Республика Крым', status: 'Потенциальный', potential: 57, revenue: 'малая', revenueMillions: 74, growth: '+16,1%', need: 'Wi-Fi для гостей', budget: '6 млн ₽', direction: 'Туризм', goal: 'Рост бронирований', margin: '18%' },
]

// Отдельный каталог из загруженных выгрузок РМСП. Не используется радаром, чтобы карта отражала только отобранные целевые компании.
const importedCompanies = [
  { name: 'ООО «ЮгТрансСервис»', inn: '6164012345', industry: 'Логистика', region: 'Ростовская область', status: 'Действующий', potential: 72, revenue: 'средняя', revenueMillions: 460, growth: '+9,4%', need: 'Мониторинг автопарка', budget: '32 млн ₽', direction: 'Грузовые перевозки', goal: 'Сокращение простоев', margin: '16%' },
  { name: 'ООО «КубаньПолимер»', inn: '2312019876', industry: 'Промышленность', region: 'Краснодарский край', status: 'Действующий', potential: 78, revenue: 'средняя', revenueMillions: 730, growth: '+12,2%', need: 'Промышленный интернет', budget: '74 млн ₽', direction: 'Производство пластмасс', goal: 'Расширение производства', margin: '19%' },
  { name: 'ИП «Астраханский рыбак»', inn: '301701234567', industry: 'Промышленность', region: 'Астраханская область', status: 'Действующий', potential: 61, revenue: 'малая', revenueMillions: 38, growth: '+7,8%', need: 'Защищенный интернет', budget: '3 млн ₽', direction: 'Рыболовство', goal: 'Выход на маркетплейсы', margin: '12%' },
  { name: 'ООО «ВолгаСтройЮг»', inn: '3445012765', industry: 'Промышленность', region: 'Волгоградская область', status: 'Действующий', potential: 69, revenue: 'средняя', revenueMillions: 520, growth: '+10,1%', need: 'Облачные сервисы', budget: '46 млн ₽', direction: 'Строительство', goal: 'Цифровизация проектов', margin: '17%' },
  { name: 'ИП «Адыгея Трейд»', inn: '010601234567', industry: 'Ритейл', region: 'Республика Адыгея', status: 'Действующий', potential: 55, revenue: 'малая', revenueMillions: 29, growth: '+11,4%', need: 'Онлайн-кассы и связь', budget: '2 млн ₽', direction: 'Оптовая торговля', goal: 'Открытие новых точек', margin: '13%' },
  { name: 'ООО «Степь-Агро»', inn: '0816012468', industry: 'АПК', region: 'Республика Калмыкия', status: 'Действующий', potential: 64, revenue: 'средняя', revenueMillions: 310, growth: '+8,7%', need: 'Умное земледелие', budget: '28 млн ₽', direction: 'Растениеводство', goal: 'Рост урожайности', margin: '15%' },
  { name: 'ООО «Крымский берег»', inn: '9104012345', industry: 'Ритейл', region: 'Республика Крым', status: 'Действующий', potential: 59, revenue: 'малая', revenueMillions: 96, growth: '+14,3%', need: 'Wi-Fi для бизнеса', budget: '7 млн ₽', direction: 'Гостиничный бизнес', goal: 'Рост загрузки', margin: '18%' },
  { name: 'ИП «СевасТех»', inn: '920401234567', industry: 'Телеком', region: 'г. Севастополь', status: 'Действующий', potential: 67, revenue: 'малая', revenueMillions: 42, growth: '+20,1%', need: 'Облачная телефония', budget: '5 млн ₽', direction: 'ИТ-услуги', goal: 'Рост клиентской базы', margin: '22%' },
] as const

const allCompanies = [...companies, ...importedCompanies]

type LocalUser = { firstName: string; lastName: string; phone: string; email: string }

function LocalAuth({ onAuthenticated }: { onAuthenticated: (user: LocalUser) => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [step, setStep] = useState<'credentials' | 'code'>('credentials')
  const [form, setForm] = useState<LocalUser>({ firstName: '', lastName: '', phone: '', email: '' })
  const [code, setCode] = useState('')
  const [error, setError] = useState('')
  const demoCode = '4829'

  const updateForm = (field: keyof LocalUser, value: string) => setForm(current => ({ ...current, [field]: value }))

  const submitCredentials = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setError('')
    if (mode === 'register' && (!form.firstName || !form.lastName || !form.phone)) {
      setError('Заполните имя, фамилию и телефон')
      return
    }
    if (!form.email) {
      setError('Введите почту')
      return
    }
    if (mode === 'login') {
      const saved = localStorage.getItem('yufo-local-user')
      if (!saved) {
        setError('Профиль не найден. Сначала зарегистрируйтесь')
        return
      }
      try {
        const savedUser = JSON.parse(saved) as LocalUser
        if (savedUser.email.toLowerCase() !== form.email.toLowerCase()) {
          setError('Пользователь с такой почтой не зарегистрирован')
          return
        }
        setForm(savedUser)
      } catch {
        setError('Не удалось прочитать локальный профиль')
        return
      }
    }
    setStep('code')
  }

  const submitCode = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (code !== demoCode) {
      setError('Введите код подтверждения из сообщения')
      return
    }
    localStorage.setItem('yufo-local-user', JSON.stringify(form))
    onAuthenticated(form)
  }

  const switchMode = (nextMode: 'login' | 'register') => {
    setMode(nextMode)
    setStep('credentials')
    setCode('')
    setError('')
  }

  return <main className="auth-shell"><section className="auth-card"><div className="brand auth-brand"><div className="brand-mark">Р</div><div><strong>Ростелеком</strong><span>Рабочая система ЮФО</span></div></div><p className="eyebrow">ЛИЧНЫЙ КАБИНЕТ</p><div className="auth-tabs" role="tablist"><button className={mode === 'login' ? 'auth-tab active' : 'auth-tab'} type="button" onClick={() => switchMode('login')}>Вход</button><button className={mode === 'register' ? 'auth-tab active' : 'auth-tab'} type="button" onClick={() => switchMode('register')}>Регистрация</button></div><h1>{mode === 'login' ? 'Вход в рабочую систему' : 'Регистрация в рабочей системе'}</h1>{step === 'credentials' ? <form onSubmit={submitCredentials} className="auth-form">{mode === 'register' && <><label>Имя<input value={form.firstName} onChange={e => updateForm('firstName', e.target.value)} autoComplete="given-name" required /></label><label>Фамилия<input value={form.lastName} onChange={e => updateForm('lastName', e.target.value)} autoComplete="family-name" required /></label><label>Телефон<input value={form.phone} onChange={e => updateForm('phone', e.target.value)} type="tel" autoComplete="tel" required /></label></>}<label>Почта<input value={form.email} onChange={e => updateForm('email', e.target.value)} type="email" autoComplete="email" required /></label><button className="button primary" type="submit">{mode === 'login' ? 'Получить код для входа' : 'Зарегистрироваться и получить код'}</button></form> : <form onSubmit={submitCode} className="auth-form"><label>Код подтверждения<input value={code} onChange={e => setCode(e.target.value)} inputMode="numeric" maxLength={6} autoFocus required /></label><p className="auth-code">Код подтверждения для демо: <strong>{demoCode}</strong></p><p className="auth-destination">Код отправлен на {form.email}</p><button className="button primary" type="submit">{mode === 'login' ? 'Войти в личный кабинет' : 'Завершить регистрацию'}</button><button className="text-button" type="button" onClick={() => setStep('credentials')}>Изменить данные</button></form>}{error && <p className="auth-error" role="alert">{error}</p>}<small className="auth-note">Двухфакторная проверка включена.</small></section></main>
}

const yufoRegions = ['Краснодарский край', 'Ростовская область', 'Волгоградская область', 'Астраханская область', 'Республика Адыгея', 'Республика Калмыкия', 'Республика Крым', 'г. Севастополь']

const projects = [
  { name: 'Модернизация производственного кластера ЮФО', investor: 'АО «Ростовский электрометаллургический завод»', region: 'Ростовская область', stage: 'Строительство', budget: '1,1 млрд ₽', date: 'Q3 2027', score: 91, need: 'Промышленный интернет, безопасность' },
  { name: 'Цифровой агропарк Краснодарского края', investor: 'ООО «ЮгАгроХолдинг»', region: 'Краснодарский край', stage: 'Проектирование', budget: '140 млн ₽', date: 'Q2 2027', score: 86, need: 'Корпоративная сеть, IoT' },
  { name: 'Умный порт Астраханской области', investor: 'ООО «Астраханский порт»', region: 'Астраханская область', stage: 'Запуск', budget: '390 млн ₽', date: 'Q1 2027', score: 82, need: 'Резервирование, ЦОД' },
]

const whiteSpots = [
  { region: 'Волгоградская область', city: 'Волгоград', potential: 88, coverage: 19, budget: '2,4 млрд ₽', signal: 'Низкая представленность клиентов', need: 'АСУ ТП, защищённая связь', basis: '18 крупных предприятий и 4 проекта модернизации' },
  { region: 'Астраханская область', city: 'Астрахань', potential: 84, coverage: 24, budget: '1,1 млрд ₽', signal: 'Высокий инвестиционный цикл', need: 'ЦОД, мониторинг объектов', basis: 'Порт, судостроение и рыбопереработка' },
  { region: 'Республика Калмыкия', city: 'Элиста', potential: 76, coverage: 12, budget: '420 млн ₽', signal: 'Свободная региональная ниша', need: 'IoT для АПК, интернет', basis: 'Агропроекты и инфраструктура региона' },
  { region: 'Республика Адыгея', city: 'Майкоп', potential: 71, coverage: 17, budget: '310 млн ₽', signal: 'Недостаток цифровой инфраструктуры', need: 'Облачные сервисы, видеосвязь', basis: 'МСБ и региональные производственные площадки' },
]

const federalPlayers = [
  { name: 'ПАО «Ростелеком»', regions: 'ЮФО', type: 'Федеральный игрок', signal: 'Единая сеть и ЦОД' },
  { name: 'ПАО «МегаФон»', regions: 'ЮФО', type: 'Кросс-региональный игрок', signal: 'Связь и IoT' },
  { name: 'ПАО «ВымпелКом»', regions: 'ЮФО', type: 'Кросс-региональный игрок', signal: 'Корпоративные коммуникации' },
]

function exportExcel(rows: Record<string, string | number>[], filename: string) {
  if (!rows.length) return
  const worksheet = utils.json_to_sheet(rows)
  worksheet['!cols'] = Object.keys(rows[0]).map(header => ({ wch: Math.min(42, Math.max(14, header.length + 4)) }))
  worksheet['!autofilter'] = { ref: `A1:${utils.encode_col(Object.keys(rows[0]).length - 1)}${rows.length + 1}` }
  worksheet['!freeze'] = { xSplit: 0, ySplit: 1 }
  const workbook = utils.book_new()
  utils.book_append_sheet(workbook, worksheet, 'Данные')
  const excel = write(workbook, { bookType: 'xlsx', type: 'array' })
  const blob = new Blob([excel], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename.replace(/\.csv$/i, '.xlsx')
  anchor.style.display = 'none'
  document.body.appendChild(anchor)
  anchor.click()
  anchor.remove()
  URL.revokeObjectURL(url)
}

export function RostelecomDashboard() {
  const [localUser, setLocalUser] = useState<LocalUser | null>(null)
  const [authReady, setAuthReady] = useState(false)
  const [module, setModule] = useState<Module>('overview')
  const [mobileNav, setMobileNav] = useState(false)
  const [toast, setToast] = useState('')
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const [region, setRegion] = useState('ЮФО')
  const [industry, setIndustry] = useState('Все отрасли')
  const [largeOnly, setLargeOnly] = useState(false)
  const [companyGroup, setCompanyGroup] = useState('Все компании')
  const [search, setSearch] = useState('')
  const [saved, setSaved] = useState(false)
  const [scenario, setScenario] = useState('Базовый')
  const [objects, setObjects] = useState(12)
  const [margin, setMargin] = useState(24)
  const [cost, setCost] = useState(18.4)
  const [selectedCompany, setSelectedCompany] = useState<(typeof companies[number]) | null>(null)
  const [importStatus, setImportStatus] = useState('')
  const [history, setHistory] = useState<HistoryItem[]>([])
  const [uploadedCompanies, setUploadedCompanies] = useState<Array<(typeof companies)[number]>>([])
  const [exports, setExports] = useState<ExportItem[]>([])
  const [darkMode, setDarkMode] = useState(false)

  useEffect(() => {
    try {
      const savedUser = localStorage.getItem('yufo-local-user')
      const savedHistory = localStorage.getItem('yufo-local-history')
      const savedCompanies = localStorage.getItem('yufo-uploaded-companies')
      const savedExports = localStorage.getItem('yufo-export-history')
      if (savedUser) setLocalUser(JSON.parse(savedUser))
      if (savedCompanies) setUploadedCompanies(JSON.parse(savedCompanies))
      if (savedExports) setExports(JSON.parse(savedExports))
      if (savedHistory) {
        const storedHistory = JSON.parse(savedHistory) as HistoryItem[]
        const meaningfulHistory = storedHistory.filter(item => item.action !== 'Переход')
        setHistory(meaningfulHistory)
      }
    } catch {
      localStorage.removeItem('yufo-local-user')
    } finally {
      setAuthReady(true)
    }
  }, [])

  useEffect(() => {
    const savedTheme = localStorage.getItem('yufo-theme')
    if (savedTheme === 'dark' || (savedTheme === null && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setDarkMode(true)
    }

    const onThemeShortcut = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'j') {
        event.preventDefault()
        setDarkMode(current => !current)
      }
    }
    window.addEventListener('keydown', onThemeShortcut)
    return () => window.removeEventListener('keydown', onThemeShortcut)
  }, [])

  useEffect(() => {
    document.documentElement.dataset.theme = darkMode ? 'dark' : 'light'
    localStorage.setItem('yufo-theme', darkMode ? 'dark' : 'light')
  }, [darkMode])

  const addHistory = (action: string, detail: string) => {
    const item: HistoryItem = { id: `${Date.now()}-${Math.random()}`, action, detail, time: new Date().toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) }
    setHistory(current => { const next = [item, ...current].slice(0, 100); localStorage.setItem('yufo-local-history', JSON.stringify(next)); return next })
  }

  const filterCatalog = (catalog: readonly (typeof companies[number])[], includeLargeOnly = false) => catalog.filter(c => {
    const isYufo = yufoRegions.includes(c.region)
    const matchesRegion = region === 'ЮФО' || c.region === region
    const matchesIndustry = industry === 'Все отрасли' || c.industry === industry
    const query = search.trim().toLowerCase()
    const matchesSearch = !query || c.name.toLowerCase().includes(query) || c.inn.includes(query)
    const matchesSize = !includeLargeOnly || c.revenueMillions >= 1000
    return isYufo && matchesRegion && matchesIndustry && matchesSize && matchesSearch
  })
  const filteredCompanies = useMemo(() => filterCatalog(companies, largeOnly), [region, industry, largeOnly, search])
  const catalogSource = useMemo(() => [...allCompanies, ...uploadedCompanies], [uploadedCompanies])
  const catalogCompanies = useMemo(() => filterCatalog(catalogSource), [catalogSource, region, industry, search])

  const trackExport = (fileName: string, title: string, rows: number) => {
    const item: ExportItem = { id: `${Date.now()}-${Math.random()}`, fileName, title, rows, createdAt: new Date().toLocaleString('ru-RU') }
    setExports(current => { const next = [item, ...current].slice(0, 50); localStorage.setItem('yufo-export-history', JSON.stringify(next)); return next })
    addHistory('Файл успешно экспортирован', `${title} · ${fileName}`)
    setToast(`Файл «${fileName}» успешно экспортирован`)
    window.setTimeout(() => setToast(''), 4000)
  }

  const exportCompany = (company: typeof companies[number]) => {
    const row = { Компания: company.name, ИНН: company.inn, Сегмент: company.revenueMillions >= 1000 ? 'Крупное предприятие' : 'ИП / МСБ', Отрасль: company.industry, Регион: company.region, Статус: company.status, Источник: (company as { sourceFile?: string }).sourceFile ?? 'Реестр ЮФО', Бюджет: company.budget, Направленность: company.direction, Цель: company.goal, Маржинальность: company.margin, Выручка: company.revenue, Рост: company.growth, Потенциал: company.potential }
    const fileName = `kompaniya-${company.inn || company.name.replace(/[^a-zа-яё0-9]+/gi, '-').toLowerCase()}.xlsx`
    exportExcel([row], fileName)
    trackExport(fileName, `Карточка компании: ${company.name}`, 1)
  }

  const exportCurrentData = () => {
    if (module === 'companies') {
      const rows = catalogCompanies.map(c => ({ Компания: c.name, ИНН: c.inn, Сегмент: c.revenueMillions >= 1000 ? 'Крупное предприятие' : 'ИП / МСБ', Отрасль: c.industry, Регион: c.region, Статус: c.status, Бюджет: c.budget, Направленность: c.direction, Цель: c.goal, Маржинальность: c.margin, 'Выручка': c.revenue, Рост: c.growth, Потенциал: c.potential }))
      if (rows.length) { const fileName = `kompanii-yufo-${region === 'ЮФО' ? 'vse-regiony' : region}.csv`; exportExcel(rows, fileName); trackExport(fileName, 'Каталог компаний ЮФО', rows.length) }
      return
    }
    if (module === 'navigator') {
      const rows = projects.map(project => ({ Проект: project.name, Инвестор: project.investor, Регион: project.region, Стадия: project.stage, Бюджет: project.budget, 'Плановый запуск': project.date, Потенциал: project.score, Потребности: project.need })); const fileName = 'investicionnye-proekty-yufo.xlsx'; exportExcel(rows, fileName); trackExport(fileName, 'Инвестиционные проекты ЮФО', rows.length)
      return
    }
    if (module === 'calculator') {
      const calculation = { Проект: selectedCompany?.name ?? 'Производственный кластер ЮФО', Компания: selectedCompany?.name ?? 'Не выбрана', Регион: selectedCompany?.region ?? 'ЮФО', Сценарий: scenario, Объекты: objects, 'Стоимость проекта, млн ₽': totalCost.toFixed(2), 'Цена предложения, млн ₽': salePrice.toFixed(2), 'Прибыль, млн ₽': profit.toFixed(2), 'Маржинальность, %': safeMargin }
      const fileName = 'raschet-sdelki-yufo.xlsx'; exportExcel([calculation], fileName); trackExport(fileName, `Расчёт: ${calculation.Компания}`, 1)
      addHistory('Расчёт экспортирован', `${calculation.Компания} · ${calculation['Цена предложения, млн ₽']} млн ₽`)
      return
    }
    exportExcel(filteredCompanies.map(c => ({ Компания: c.name, ИНН: c.inn, Отрасль: c.industry, Регион: c.region, Бюджет: c.budget, Потенциал: c.potential })), 'vyborka-kompanij-yufo.xlsx')
  }

  const safeCost = Number.isFinite(cost) ? Math.max(0, cost) : 0
  const safeObjects = Number.isFinite(objects) ? Math.max(1, objects) : 1
  const safeMargin = Number.isFinite(margin) ? Math.max(0, margin) : 0
  const totalCost = safeCost * safeObjects * (scenario === 'Экономичный' ? 0.86 : scenario === 'Расширенный' ? 1.24 : 1)
  const salePrice = totalCost * (1 + safeMargin / 100)
  const profit = salePrice - totalCost

  if (!authReady) return null
  if (!localUser) return <LocalAuth onAuthenticated={setLocalUser} />
  const logout = () => {
    localStorage.removeItem('yufo-local-user')
    setLocalUser(null)
  }

  const navItems: { id: Module; label: string; icon: typeof LayoutDashboard }[] = [
    { id: 'profile', label: 'Личный кабинет', icon: Users },
    { id: 'overview', label: 'Аналитическая панель', icon: LayoutDashboard },
    { id: 'radar', label: 'Радар присутствия', icon: Target },
    { id: 'companies', label: 'Все компании', icon: Building2 },
    { id: 'navigator', label: 'Инвестиционный навигатор', icon: Map },
    { id: 'calculator', label: 'Калькулятор сделок', icon: Calculator },
    { id: 'compare', label: 'Советник и сравнение', icon: Sparkles },
  { id: 'create', label: 'Создать компанию', icon: Building2 },
  ]

  const title = module === 'overview' ? 'Аналитическая панель' : navItems.find(item => item.id === module)?.label

  return (
    <div className={`app-shell ${darkMode ? 'theme-dark' : ''}`}>
      <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
        <div className="brand"><div className="brand-mark">Р</div><div><strong>Ростелеком</strong><span>Рабочая система ЮФО</span></div><button className="mobile-close" onClick={() => setMobileNav(false)} aria-label="Закрыть меню"><X size={18} /></button></div>
        <nav className="nav-list" aria-label="Основная навигация">
          {navItems.map(item => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${module === item.id ? 'active' : ''}`} onClick={() => { setModule(item.id); setMobileNav(false) }}><Icon size={18} />{item.label}</button> })}
        </nav>
      </aside>
      {mobileNav && <button className="scrim" onClick={() => setMobileNav(false)} aria-label="Закрыть меню" />}
      <main className="main-content">
        <header className="topbar"><button className="mobile-menu" onClick={() => setMobileNav(true)} aria-label="Открыть меню"><Menu size={21} /></button><div className="breadcrumbs">Экосистема <span>/</span> {title}</div><div className="top-actions"><span className="updated"><span className="status-dot" /> Данные обновлены сегодня, 09:42</span><button className="icon-button" title={`${darkMode ? 'Светлая' : 'Тёмная'} тема · Ctrl/⌘ + J`} aria-label={darkMode ? 'Включить светлую тему' : 'Включить тёмную тему'} onClick={() => setDarkMode(current => !current)}>{darkMode ? <span aria-hidden="true">☀</span> : <span aria-hidden="true">◐</span>}</button><div className="notification-wrap"><button className="icon-button" aria-label="Уведомления" onClick={() => setNotificationsOpen(current => !current)}><Bell size={19} /><i /></button>{notificationsOpen && <div className="notification-popover"><div className="notification-head"><strong>Уведомления</strong><button onClick={() => setNotificationsOpen(false)} aria-label="Закрыть уведомления"><X size={14} /></button></div>{history.slice(0, 4).map(item => <div className="notification-item" key={item.id}><span className="status-dot" /><div><strong>{item.action}</strong><small>{item.detail}</small><time>{item.time}</time></div></div>)}{history.length === 0 && <p className="notification-empty">Здесь появятся результаты экспорта, загрузки и расчётов.</p>}</div>}</div><div className="top-avatar">ЛК</div></div></header>
        <div className="content-wrap">
          <div className="page-heading"><div><p className="eyebrow">КОММЕРЧЕСКАЯ АНАЛИТИКА</p><h1>{title}</h1><p className="heading-copy">Единая среда для поиска возможностей, оценки проектов и подготовки предложений</p></div><div className="heading-actions"><button className="button secondary" onClick={exportCurrentData}><Download size={16} /> Экспорт в Excel: {module === 'navigator' ? 'проекты' : module === 'calculator' ? 'расчёт' : module === 'companies' ? 'компании' : 'выборка'}</button><button className="button primary" onClick={() => setModule('calculator')}><Calculator size={16} /> Новый расчёт</button></div></div>
          {module === 'overview' && <Overview setModule={setModule} />}
          {module === 'radar' && <Radar region={region} setRegion={setRegion} industry={industry} setIndustry={setIndustry} largeOnly={largeOnly} setLargeOnly={setLargeOnly} search={search} setSearch={setSearch} filteredCompanies={filteredCompanies} saved={saved} setSaved={setSaved} setModule={setModule} />}
          {module === 'companies' && <Companies region={region} setRegion={setRegion} industry={industry} setIndustry={setIndustry} search={search} setSearch={setSearch} companyGroup={companyGroup} setCompanyGroup={setCompanyGroup} filteredCompanies={catalogCompanies} setSelectedCompany={(company: typeof companies[number]) => { setSelectedCompany(company); addHistory('Компания выбрана', company.name); setModule('calculator') }} exportCompany={exportCompany} importStatus={importStatus} setImportStatus={setImportStatus} addHistory={(action: string, detail: string) => { addHistory(action, detail); setToast(`${action}: ${detail}`); setTimeout(() => setToast(''), 4000) }} uploadedCompanies={uploadedCompanies} setUploadedCompanies={setUploadedCompanies} />}
          {module === 'profile' && <Profile user={localUser} history={history} onLogout={logout} onClearHistory={() => { setHistory([]); localStorage.removeItem('yufo-local-history') }} />}
          {module === 'navigator' && <Navigator setModule={setModule} />}
          {module === 'calculator' && <CalculatorModule scenario={scenario} setScenario={setScenario} objects={objects} setObjects={setObjects} margin={margin} setMargin={setMargin} cost={cost} setCost={setCost} totalCost={totalCost} salePrice={salePrice} profit={profit} selectedCompany={selectedCompany} onExport={exportCurrentData} />}
          {module === 'compare' && <CompareAdvisor companies={catalogCompanies} onNotify={(message) => { setToast(message); setTimeout(() => setToast(''), 4000) }} />}
  {module === 'create' && <CreateCompany onCreate={(company) => { setUploadedCompanies(current => { const next = [...current, company]; localStorage.setItem('yufo-uploaded-companies', JSON.stringify(next)); return next }); addHistory('Компания создана', company.name); setToast(`Компания «${company.name}» добавлена в каталог`); setTimeout(() => setToast(''), 4000); setModule('compare') }} />}
        </div>
        {toast && <div className="toast" role="status"><Sparkles size={16} />{toast}</div>}
      </main>
    </div>
  )
}

function WhiteSpotPanel({ setModule }: { setModule: (m: Module) => void }) {
  const [activeRegion, setActiveRegion] = useState('ЮФО')
  const spots = activeRegion === 'ЮФО' ? whiteSpots : whiteSpots.filter(spot => spot.region === activeRegion)
  return <section className="panel opportunity-intelligence">
    <div className="table-heading"><div><p className="eyebrow">АВТОМАТИЧЕСКИЙ ПОИСК</p><h2>Белые пятна ЮФО</h2><p className="table-subtitle">Регионы с высоким потенциалом и низкой представленностью действующих клиентов</p></div><button className="button secondary compact-button" onClick={() => setModule('radar')}><Target size={15} /> Открыть на радаре</button></div>
    <div className="spot-toolbar"><span className="spot-count"><strong>{spots.length}</strong> приоритетных зон</span><select aria-label="Регион для анализа белых пятен" value={activeRegion} onChange={event => setActiveRegion(event.target.value)}><option>ЮФО</option>{yufoRegions.map(item => <option key={item}>{item}</option>)}</select></div>
    <div className="spot-grid">{spots.map(spot => <article className="spot-card" key={spot.region}><div className="spot-card-head"><div><strong>{spot.city}</strong><span>{spot.region}</span></div><b>{spot.potential}</b></div><div className="spot-meter"><i style={{ width: `${spot.potential}%` }} /></div><p className="spot-signal">{spot.signal}</p><dl><div><dt>Покрытие</dt><dd>{spot.coverage}%</dd></div><div><dt>Рынок</dt><dd>{spot.budget}</dd></div></dl><small>{spot.basis}</small><button className="table-link" onClick={() => setModule('calculator')}>Рассчитать предложение →</button></article>)}</div>
    <div className="player-strip"><div><strong>Федеральные и кросс-региональные игроки</strong><span>Сигналы для проверки конкуренции и партнёрской модели</span></div>{federalPlayers.map(player => <span className="player-chip" key={player.name}>{player.name}<small>{player.signal}</small></span>)}</div>
  </section>
}

function CompareAdvisor({ companies, onNotify }: { companies: CompanyRecord[]; onNotify: (message: string) => void }) {
  const [first, setFirst] = useState(companies[0]?.inn ?? '')
  const [second, setSecond] = useState(companies[1]?.inn ?? '')
  const advisorQuestions = [
    'Какой проект выбрать первым: где быстрее окупаемость и выше прибыль?',
    'Какая компания даст лучшую маржинальность при меньшем бюджете?',
    'Где выше спрос на цифровые решения и почему регион важен?',
    'Какие риски могут сорвать запуск и что проверить до вложений?',
    'Какой проект реалистично запустить за 30 дней и с чего начать?',
  ]
  const [question, setQuestion] = useState(advisorQuestions[0])
  const [advice, setAdvice] = useState('')
  const [loading, setLoading] = useState(false)
  const selected = companies.filter(company => company.inn === first || company.inn === second)
  const parseMillions = (value: string) => Number(value.replace(/[^0-9,]/g, '').replace(',', '.')) * (value.includes('млрд') ? 1000 : 1)
  const payback = selected.map(company => { const budget = parseMillions(company.budget); const marginPercent = Number(company.margin.replace(',', '.').replace('%', '')); const annualProfit = budget * marginPercent / 100; return { ...company, budgetMillions: budget, annualProfitMillions: annualProfit, payback: annualProfit > 0 ? (budget / annualProfit * 12).toFixed(1) : 'нет данных' } })
  const askAdvisor = async () => { setLoading(true); try { const response = await fetch('/api/advisor', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ companies: selected, question }) }); const data = await response.json(); if (!response.ok) throw new Error(data.error); setAdvice(data.text); onNotify('Советник подготовил сравнение компаний') } catch (error) { onNotify(error instanceof Error ? error.message : 'Не удалось получить совет'); } finally { setLoading(false) } }
  const exportWord = () => {
    const escapeHtml = (value: unknown) => String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;')
    const rows = payback.map(company => `<tr><td>${escapeHtml(company.name)}</td><td>${escapeHtml(company.region)}</td><td>${escapeHtml(company.budget)}</td><td>${escapeHtml(company.margin)}</td><td>${company.potential}/100</td><td>${company.payback} мес.</td></tr>`).join('')
    const formatAdvice = (value: string) => value.split('\n').map(line => { const safeLine = escapeHtml(line.trim()); if (!safeLine) return ''; if (/^###?\s/.test(line)) return `<h3>${safeLine.replace(/^###?\s/, '')}</h3>`; if (/^[-•]\s/.test(line)) return `<p class="list-item">${safeLine.replace(/^[-•]\s/, '')}</p>`; return `<p>${safeLine}</p>` }).join('')
    const documentHtml = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Аналитическое заключение Ростелеком</title><style>@page{size:A4;margin:20mm 15mm 20mm 30mm}body{font-family:'Times New Roman',serif;font-size:14pt;line-height:1.5;color:#111}h1{text-align:center;font-size:16pt;text-transform:uppercase;margin:0 0 18pt}h2{font-size:14pt;text-align:left;margin:18pt 0 8pt}h3{font-size:13pt;text-align:left;margin:14pt 0 6pt}p{text-align:justify;text-indent:1.25cm;margin:0 0 8pt}.list-item{text-indent:0;margin-left:1.25cm}.list-item:before{content:'— ';}.header{text-align:center;margin-bottom:70pt}.header p{text-align:center;text-indent:0;margin:0}.meta{margin:16pt 0}.meta p{text-indent:0}.table{width:100%;border-collapse:collapse;margin:10pt 0;font-size:10pt}.table th,.table td{border:1px solid #111;padding:5pt;vertical-align:top}.table th{text-align:center;font-weight:bold}.note{font-size:11pt}.signature{margin-top:42pt;display:flex;justify-content:space-between}.page-break{page-break-before:always}</style></head><body><div class="header"><p><b>ПАО «РОСТЕЛЕКОМ»</b></p><p>Внутренний аналитический документ</p><br><p>УТВЕРЖДАЮ</p><p>Руководитель направления</p><p>________________ / __________________</p><br><p>«___» __________ 2026 г.</p></div><h1>АНАЛИТИЧЕСКОЕ ЗАКЛЮЧЕНИЕ</h1><p style="text-align:center;text-indent:0"><b>Сравнительная оценка инвестиционных проектов компаний ЮФО</b></p><div class="meta"><p><b>Основание:</b> запрос советника — ${escapeHtml(question)}</p><p><b>Объект оценки:</b> ${selected.length} компании из внутреннего каталога проектов.</p><p><b>Дата формирования:</b> ${new Date().toLocaleDateString('ru-RU')}</p></div><h2>1 Общие положения</h2><p>Настоящее заключение подготовлено для предварительного сопоставления проектов по экономическим и коммерческим показателям. Выводы сформированы на основании данных, доступных в рабочей среде, и предназначены для принятия решения о приоритетности дальнейшей проработки.</p><h2>2 Сравнительная характеристика</h2><table class="table"><thead><tr><th>Компания</th><th>Регион</th><th>Бюджет</th><th>Маржа</th><th>Потенциал</th><th>Окупаемость</th></tr></thead><tbody>${rows}</tbody></table><h2>3 Аналитический вывод и рекомендация</h2><div>${formatAdvice(advice || 'Вывод не сформирован. Выполните сравнение проектов перед экспортом.')}</div><h2>4 Методика расчёта</h2><p>Расчётная годовая прибыль определяется как произведение бюджета проекта на процент маржинальности, делённое на 100. Срок окупаемости определяется как отношение бюджета к расчётной годовой прибыли, умноженное на 12 месяцев. Показатели являются аналитической оценкой и требуют проверки первичными документами, сметой, договорными условиями и подтверждёнными сроками реализации.</p><h2>5 Итоговая рекомендация</h2><p>До принятия инвестиционного решения необходимо подтвердить бюджет, состав работ, стоимость оборудования и программного обеспечения, доступность инфраструктуры, наличие спроса, конкурентную среду и план масштабирования. Рекомендуемый следующий шаг — провести пилотный проект с контрольными показателями бюджета, срока и фактической маржи.</p><p class="note"><b>Примечание.</b> Документ подготовлен автоматически для внутреннего использования. Он не является финансовой гарантией или заменой юридической, технической и финансовой экспертизы.</p><div class="signature"><span>Исполнитель: __________________</span><span>Дата: ______________</span></div></body></html>`
    const blob = new Blob([documentHtml], { type: 'application/msword' })
    const url = URL.createObjectURL(blob); const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'analiticheskoe-zaklyuchenie-rostelekom.doc'; anchor.click(); URL.revokeObjectURL(url); onNotify('Официальный Word-документ успешно экспортирован')
  }
  return <section className="compare-page"><div className="compare-hero"><div><p className="eyebrow">ИНВЕСТИЦИОННЫЙ СОВЕТНИК</p><h2>Сравнение проектов</h2><p>Выберите две компании из разных регионов или одной сферы — советник сравнит бюджет, маржинальность, потенциал, окупаемость и объяснит решение.</p></div><Sparkles size={34} /></div><div className="compare-controls"><label>Компания 1<select value={first} onChange={event => setFirst(event.target.value)}>{companies.map(company => <option value={company.inn} key={company.inn}>{company.name} · {company.region}</option>)}</select></label><label>Компания 2<select value={second} onChange={event => setSecond(event.target.value)}>{companies.map(company => <option value={company.inn} key={company.inn}>{company.name} · {company.region}</option>)}</select></label><label className="compare-question">Вопрос советнику<input value={question} onChange={event => setQuestion(event.target.value)} /></label><div className="advisor-questions">{advisorQuestions.map(item => <button type="button" key={item} className={question === item ? 'active' : ''} onClick={() => setQuestion(item)}>{item}</button>)}</div><button className="button primary" onClick={askAdvisor} disabled={loading || selected.length < 2}>{loading ? 'Анализирую…' : 'Сравнить и объяснить'}</button></div><div className="compare-cards">{payback.map(company => <article className="compare-card" key={company.inn}><span>{company.region}</span><h3>{company.name}</h3><dl><div><dt>Бюджет</dt><dd>{company.budget}</dd></div><div><dt>Маржинальность</dt><dd>{company.margin}</dd></div><div><dt>Потенциал</dt><dd>{company.potential}/100</dd></div><div><dt>Окупаемость</dt><dd>{company.payback} мес.</dd></div></dl></article>)}</div><div className="advisor-result"><div className="result-head"><div><p className="eyebrow">ОБЪЯСНЕНИЕ АГЕНТА</p><h3>Рекомендация и выводы</h3></div><button className="button secondary" onClick={exportWord} disabled={!advice}><FileText size={15} /> Экспорт в Word</button></div>{advice ? <div className="advisor-copy">{advice}</div> : <p className="notification-empty">Запустите сравнение — советник объяснит, какой проект выгоднее, быстрее окупится и какие риски нужно проверить.</p>}</div></section>
}

function CreateCompany({ onCreate }: { onCreate: (company: CompanyRecord) => void }) {
  const [form, setForm] = useState({ name: '', industry: 'Строительство', region: 'Краснодарский край', budget: '', margin: '', paybackYears: '3' })
  const budget = Number(form.budget.replace(',', '.')) || 0
  const marginValue = Number(form.margin.replace(',', '.')) || 0
  const annualProfit = budget * marginValue / 100
  const paybackYears = annualProfit > 0 ? budget / annualProfit : 0
  const submit = (event: React.FormEvent) => { event.preventDefault(); if (!form.name.trim() || budget <= 0 || marginValue <= 0) return; onCreate({ name: form.name.trim(), inn: `NEW-${Date.now()}`, industry: form.industry, region: form.region, status: 'Создано пользователем', potential: Math.min(99, Math.round(marginValue * 2 + 40)), revenue: 'Новая компания', revenueMillions: budget, growth: 'Расчётная модель', need: 'Требует определения', budget: `${budget.toFixed(1)} млн ₽`, direction: form.industry, goal: `Окупаемость до ${form.paybackYears} лет`, margin: `${marginValue.toFixed(1)}%` }) }
  return <section className="create-company-page"><div className="create-hero"><div><p className="eyebrow">ВИЗУАЛИЗАЦИЯ СОЗДАНИЯ</p><h2>Паспорт новой компании</h2><p>Задайте исходную модель и сразу сравните её с компаниями из каталога.</p></div><Building2 size={34} /></div><form className="create-form" onSubmit={submit}><label>Наименование компании<input required value={form.name} onChange={event => setForm({ ...form, name: event.target.value })} placeholder="Например, ООО «ЮгСтройЦифра»" /></label><label>Сфера деятельности<select value={form.industry} onChange={event => setForm({ ...form, industry: event.target.value })}><option>Строительство</option><option>Промышленность</option><option>АПК</option><option>Логистика</option><option>Телеком</option><option>Туризм и гостеприимство</option></select></label><label>Регион<select value={form.region} onChange={event => setForm({ ...form, region: event.target.value })}>{yufoRegions.map(item => <option key={item}>{item}</option>)}</select></label><label>Исходный бюджет, млн ₽<input required type="number" min="0.1" step="0.1" value={form.budget} onChange={event => setForm({ ...form, budget: event.target.value })} /></label><label>Плановая маржинальность, %<input required type="number" min="0.1" max="100" step="0.1" value={form.margin} onChange={event => setForm({ ...form, margin: event.target.value })} /></label><label>Желаемый срок окупаемости, лет<input required type="number" min="0.5" max="30" step="0.5" value={form.paybackYears} onChange={event => setForm({ ...form, paybackYears: event.target.value })} /></label><div className="create-result"><span>Расчётная годовая прибыль</span><strong>{annualProfit.toFixed(1)} млн ₽</strong><small>Фактическая окупаемость: {paybackYears.toFixed(1)} года</small></div><button className="button primary" type="submit">Добавить компанию в каталог</button></form></section>
}

function ReadinessPassport({ setModule }: { setModule: (m: Module) => void }) {
  const dataCompleteness = Math.round((companies.filter(company => company.inn && company.region && company.industry && company.budget && company.margin).length / companies.length) * 100)
  const commercialPotential = Math.round(companies.reduce((sum, company) => sum + company.potential, 0) / companies.length)
  const averageMargin = Math.round(companies.reduce((sum, company) => sum + Number(company.margin.replace('%', '')), 0) / companies.length)
  const readiness = Math.round(dataCompleteness * 0.35 + commercialPotential * 0.4 + averageMargin * 2.5)
  const checks = [{ label: 'Данные компании и ИНН', value: dataCompleteness, status: 'Подтверждено' }, { label: 'Коммерческий потенциал', value: commercialPotential, status: commercialPotential >= 80 ? 'Высокий уровень' : 'Требует проверки' }, { label: 'Экономическая эффективность', value: Math.min(100, averageMargin * 3), status: `${averageMargin}% средняя маржинальность` }]
  return <section className="panel readiness-passport"><div className="passport-heading"><div><p className="eyebrow">КОНТРОЛЬ КАЧЕСТВА РЕШЕНИЯ</p><h2>Паспорт управленческого решения</h2><p>Единый официальный индикатор готовности проекта к передаче на следующую стадию проработки.</p></div><div className="readiness-score"><ShieldCheck size={22} /><strong>{readiness}</strong><span>из 100</span></div></div><div className="passport-body"><div className="passport-checks">{checks.map(check => <div className="passport-check" key={check.label}><div className="passport-check-title"><span>{check.label}</span><b>{check.status}</b></div><div className="passport-progress"><i style={{ width: `${check.value}%` }} /></div><small>Расчётный показатель: {check.value}/100</small></div>)}</div><div className="passport-conclusion"><span className="passport-label">СТАТУС ПРОРАБОТКИ</span><strong>{readiness >= 80 ? 'Готово к управленческому рассмотрению' : 'Требуется дополнительная проверка'}</strong><p>{readiness >= 80 ? 'В каталоге достаточно данных для приоритизации. Перед запуском необходимо подтвердить бюджет, сроки и первичные документы.' : 'Рекомендуется дополнить карточки компаний и подтвердить экономические параметры проекта.'}</p><button className="button secondary" onClick={() => setModule('compare')}>Открыть сравнение <span>→</span></button></div></div><div className="passport-footnote"><span>Методика: полнота данных 35% · потенциал 40% · маржинальность 25%</span><span>Только для внутреннего использования</span></div></section>
}

function Overview({ setModule }: { setModule: (m: Module) => void }) {
  return <>
    <div className="insight-banner"><div className="insight-icon"><Sparkles size={19} /></div><div><strong>Найдена приоритетная зона</strong><p>ЮФО: 42 компании с высоким потенциалом и низкой представленностью действующих клиентов. Рекомендуем начать с промышленного кластера.</p></div><button className="text-button" onClick={() => setModule('radar')}>Открыть радар <span>→</span></button></div>
    <WhiteSpotPanel setModule={setModule} />
    <ReadinessPassport setModule={setModule} />
    <div className="metrics-grid"><Metric label="Компании в базе" value={String(allCompanies.length)} delta="из текущей выборки" note="компании ЮФО в каталоге" icon={Building2} /><Metric label="Коммерческий потенциал" value="₽ 84,6 млн" delta="+12,7%" note="оценка по активным возможностям" icon={TrendingUp} accent /><Metric label="Инвестиционные проекты" value="186" delta="+16" note="новых за квартал" icon={BriefcaseBusiness} /><Metric label="Воронка возможностей" value="₽ 412 млн" delta="+21,3%" note="сумма бюджетов проектов" icon={Users} /></div>
    <div className="dashboard-grid"><section className="panel chart-panel"><PanelTitle title="Динамика коммерческих возможностей" action="Последние 6 месяцев" /><div className="chart-legend"><span><i className="legend-purple" /> Потенциал, млн ₽</span><span><i className="legend-gray" /> Проекты</span></div><div className="area-chart"><div className="y-labels"><span>100</span><span>75</span><span>50</span><span>25</span><span>0</span></div><svg viewBox="0 0 600 190" preserveAspectRatio="none" role="img" aria-label="График динамики возможностей"><defs><linearGradient id="fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#7337d8" stopOpacity=".25" /><stop offset="1" stopColor="#7337d8" stopOpacity="0" /></linearGradient></defs><path d="M0 148 C55 140 68 118 118 124 S175 94 224 104 S270 62 320 82 S376 70 416 52 S480 66 520 33 S565 43 600 18 V190 H0Z" fill="url(#fill)" /><path d="M0 148 C55 140 68 118 118 124 S175 94 224 104 S270 62 320 82 S376 70 416 52 S480 66 520 33 S565 43 600 18" fill="none" stroke="#7337d8" strokeWidth="3" /><path d="M0 165 C60 163 75 145 120 151 S180 132 225 145 S280 120 320 132 S375 124 420 116 S480 125 520 101 S570 112 600 94" fill="none" stroke="#b8b0c9" strokeWidth="2" strokeDasharray="5 5" /></svg><div className="x-labels"><span>Май</span><span>Июн</span><span>Июл</span><span>Авг</span><span>Сен</span><span>Окт</span></div></div></section><section className="panel"><PanelTitle title="Распределение по отраслям" action="Компании" /><div className="donut-row"><div className="donut" /><div className="donut-legend"><span><i style={{background:'#7337d8'}} /> Промышленность <b>32%</b></span><span><i style={{background:'#a98be6'}} /> АПК <b>24%</b></span><span><i style={{background:'#d1c3f0'}} /> Логистика <b>18%</b></span><span><i style={{background:'#e9e4f7'}} /> Энергетика <b>14%</b></span><span><i style={{background:'#e9e9ee'}} /> Другое <b>12%</b></span></div></div></section></div>
    <div className="dashboard-grid bottom-grid"><section className="panel"><PanelTitle title="Приоритетные возможности" action="Все возможности →" /><div className="opportunity-list"><Opportunity title="Модернизация производственного кластера ЮФО" meta="Ростовская область · Строительство" amount="₽ 1,1 млрд" score="91" /><Opportunity title="Агропарк «Южный кластер»" meta="Краснодарский край · Проектирование" amount="₽ 1,6 млрд" score="86" /><Opportunity title="Умный порт Астраханской области" meta="Астраханская область · Запуск" amount="₽ 390 млн" score="82" /></div></section><section className="panel"><PanelTitle title="Последние уведомления" action="Все уведомления →" /><div className="notification-list"><Notification text="Новый проект в Астраханской области" time="12 минут назад" type="new" /><Notification text="Изменился бюджет проекта «ЭкоГрид»" time="2 часа назад" type="change" /><Notification text="Найдено 8 компаний в белом пятне" time="Вчера" type="alert" /></div></section></div>
  </>
}

function Metric({ label, value, delta, note, icon: Icon, accent = false }: { label: string; value: string; delta: string; note: string; icon: typeof Building2; accent?: boolean }) { return <div className={`metric-card ${accent ? 'metric-accent' : ''}`}><div className="metric-top"><span>{label}</span><Icon size={18} /></div><strong>{value}</strong><div><span className="metric-delta">{delta}</span><span className="metric-note"> {note}</span></div></div> }
function PanelTitle({ title, action }: { title: string; action?: string }) { return <div className="panel-title"><h2>{title}</h2>{action && <button className="panel-action">{action}<ChevronDown size={14} /></button>}</div> }
function Opportunity({ title, meta, amount, score }: { title: string; meta: string; amount: string; score: string }) { return <div className="opportunity"><div className="opportunity-icon"><Target size={17} /></div><div className="opportunity-main"><strong>{title}</strong><span>{meta}</span></div><div className="opportunity-amount"><strong>{amount}</strong><span>потенциал <b>{score}</b></span></div></div> }
function Notification({ text, time, type }: { text: string; time: string; type: string }) { return <div className="notification"><span className={`notification-dot ${type}`} /><div><strong>{text}</strong><span>{time}</span></div></div> }

function Radar({ region, setRegion, industry, setIndustry, largeOnly, setLargeOnly, search, setSearch, filteredCompanies, saved, setSaved, setModule }: any) { return <><div className="filter-bar"><div className="search-field"><Search size={17} /><input placeholder="Поиск по названию или ИНН" aria-label="Поиск по названию или ИНН" value={search} onChange={e => setSearch(e.target.value)} /></div><select aria-label="Регион ЮФО" value={region} onChange={e => setRegion(e.target.value)}><option>ЮФО</option>{yufoRegions.map(item => <option key={item}>{item}</option>)}</select><select aria-label="Отрасль" value={industry} onChange={e => setIndustry(e.target.value)}><option>Все отрасли</option><option>Промышленность</option><option>Телеком</option><option>Энергетика</option><option>Ритейл</option><option>Логистика</option></select><label className="filter-check"><input type="checkbox" checked={largeOnly} onChange={e => setLargeOnly(e.target.checked)} /> Только крупные</label><button className={`button ${saved ? 'saved' : 'secondary'}`} onClick={() => setSaved(!saved)}>{saved ? 'Фильтр сохранён' : 'Сохранить фильтр'}</button></div><div className="radar-highlight"><div><p className="eyebrow">ТЕПЛОВАЯ ЗОНА · ЮЖНЫЙ ФЕДЕРАЛЬНЫЙ ОКРУГ</p><h2>Высокий потенциал при низкой представленности</h2><p>42 потенциальные компании · оценочный потенциал <strong>₽ 18,4 млн</strong> · уверенность 82%</p></div><button className="button primary" onClick={() => setModule('calculator')}>Оценить решение <span>→</span></button></div><div className="radar-layout"><section className="panel map-panel"><PanelTitle title="Карта присутствия" action="Точки · Плотность · Зоны" /><div className="demo-map"><LeafletPresenceMap region={region} /><div className="map-grid" /><span className="map-label label-a">Ленинградская<br />область</span><span className="map-label label-b">Москва</span><span className="map-label label-c">Татарстан</span>{[...Array(14)].map((_, i) => <i key={i} className={`map-point ${i % 3 === 0 ? 'client' : ''}`} style={{left: `${16 + (i * 29) % 68}%`, top: `${20 + (i * 43) % 58}%`}} />)}<div className="map-legend"><span><i className="client-dot" /> Действующий клиент</span><span><i className="potential-dot" /> Потенциальный</span></div></div></section><section className="panel radar-side"><PanelTitle title="Факторы рейтинга" /><div className="factor"><span>Деловая активность</span><strong>Высокая</strong><div className="progress"><i style={{width:'92%'}} /></div></div><div className="factor"><span>Инвестиционная активность</span><strong>Высокая</strong><div className="progress"><i style={{width:'84%'}} /></div></div><div className="factor"><span>Представленность клиентов</span><strong>Низкая</strong><div className="progress low"><i style={{width:'28%'}} /></div></div><div className="recommendation"><Sparkles size={16} /><span>Следующее действие<br /><b>Проверить 8 компаний с потенциалом выше 80</b></span></div></section></div><section className="panel table-panel"><div className="table-heading"><PanelTitle title="Компании в зоне" action={`${filteredCompanies.length} из 42`} /><button className="button secondary" onClick={() => exportExcel(filteredCompanies, 'companies.xlsx')}><Download size={15} /> Экспорт выборки</button></div><div className="table-scroll"><table><thead><tr><th>Компания</th><th>Отрасль</th><th>Регион</th><th>Статус</th><th>Потенциал</th><th>Рост</th><th>Потребность</th></tr></thead><tbody>{filteredCompanies.map((company: any) => <tr key={company.name}><td><strong>{company.name}</strong><small>Демонстрационная запись</small></td><td>{company.industry}</td><td>{company.region}</td><td><span className={`tag ${company.status === 'Действующий' ? 'green' : company.status === 'Потенциальный' ? 'purple' : 'gray'}`}>{company.status}</span></td><td><strong className="potential-value">{company.potential}</strong></td><td className="growth">{company.growth}</td><td>{company.need}</td></tr>)}</tbody></table></div></section></> }

function ExportsPanel({ exports, onClear }: { exports: ExportItem[]; onClear: () => void }) {
  return <section className="panel exports-panel"><div className="panel-title"><div><p className="eyebrow">АРХИВ ФАЙЛОВ</p><h2>Экспортированные файлы</h2><p>Здесь хранятся записи о Excel-файлах, которые вы скачали из системы.</p></div>{exports.length > 0 && <button className="text-button" onClick={onClear}>Очистить список</button>}</div>{exports.length === 0 ? <div className="empty-state"><FileText size={28} /><strong>Экспортов пока нет</strong><span>Сформируйте каталог, проект или расчёт — файл появится здесь.</span></div> : <div className="export-list">{exports.map(item => <article className="export-row" key={item.id}><div className="export-file-icon"><FileText size={18} /></div><div className="export-meta"><strong>{item.fileName}</strong><span>{item.title} · {item.rows} строк · {item.createdAt}</span></div><span className="export-status">Скачан</span></article>)}</div>}</section>
}

function Profile({ user, history, onLogout, onClearHistory }: { user: LocalUser; history: HistoryItem[]; onLogout: () => void; onClearHistory: () => void }) {
  return <div className="profile-page"><section className="panel profile-hero"><div className="top-avatar large">{user.firstName.slice(0, 1)}{user.lastName.slice(0, 1)}</div><div><p className="eyebrow">ЛИЧНЫЙ КАБИНЕТ</p><h2>{user.firstName} {user.lastName}</h2><p>{user.email} · {user.phone}</p></div><button className="button secondary" onClick={onLogout}>Выйти из профиля</button></section><section className="panel history-panel"><div className="panel-title"><div><h2>История расчётов и данных</h2><p className="table-subtitle">Здесь сохраняются результаты оценок, экспорты и загруженные данные компаний</p></div><button className="text-button" onClick={onClearHistory}>Очистить историю расчётов</button></div>{history.length ? <div className="history-list">{history.map(item => <div className="history-item" key={item.id}><Activity size={17} /><div><strong>{item.action}</strong><span>{item.detail}</span></div><time>{item.time}</time></div>)}</div> : <div className="empty-state">История появится после первого действия в системе</div>}</section></div>
}

function Companies({ region, setRegion, industry, setIndustry, search, setSearch, companyGroup, setCompanyGroup, filteredCompanies, setSelectedCompany, exportCompany, importStatus, setImportStatus, addHistory, uploadedCompanies, setUploadedCompanies }: any) {
  const parseCsv = (text: string, sourceFile = '') => {
    const rows = text.replace(/^\ufeff/, '').split(/\r?\n/).filter(Boolean).map(row => row.split(/;(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)|,(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)/).map(cell => cell.trim().replace(/^\"|\"$/g, '').replaceAll('\"\"', '\"')))
    if (rows.length < 2) return []
    const headers = rows[0].map(header => header.toLowerCase())
    const value = (row: string[], names: string[]) => row[headers.findIndex(header => names.some(name => header.includes(name)))] || ''
    return rows.slice(1).map((row, index) => {
      const name = value(row, ['компания', 'наименование', 'название', 'организация']) || `Компания из файла ${index + 1}`
      const revenueMillions = Number(value(row, ['выручка', 'оборот']).replace(/[^0-9.,-]/g, '').replace(',', '.')) || 0
      return { name, inn: value(row, ['инн']) || `${sourceFile}-${Date.now()}-${index}`, industry: value(row, ['отрасль', 'оквэд']) || 'Не указано', region: value(row, ['регион', 'субъект']) || 'Ростовская область', status: value(row, ['статус']) || 'Загружено пользователем', potential: Number(value(row, ['потенциал'])) || 50, revenue: revenueMillions >= 1000 ? 'крупная' : 'средняя', revenueMillions, growth: value(row, ['рост', 'динамика']) || '—', need: value(row, ['потребность']) || 'Требует оценки', budget: value(row, ['бюджет']) || '—', direction: value(row, ['направленность', 'деятельность']) || '—', goal: value(row, ['цель']) || '—', margin: value(row, ['маржинальность', 'маржа']) || '—', sourceFile }
    })
  }

  const handleFiles = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? [])
    if (!files.length) return
    const imported = (await Promise.all(files.map(async file => {
      try {
        if (/\.csv$/i.test(file.name)) return parseCsv(await file.text(), file.name)
        if (/\.xlsx?$/i.test(file.name)) {
          const workbook = read(await file.arrayBuffer(), { type: 'array' })
          return workbook.SheetNames.flatMap(sheet => parseCsv(utils.sheet_to_csv(workbook.Sheets[sheet]), file.name))
        }
        if (/\.pdf$/i.test(file.name)) {
          const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs')
          const pdf = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise
          const text = (await Promise.all(Array.from({ length: pdf.numPages }, (_, index) => pdf.getPage(index + 1).then(page => page.getTextContent()).then(content => content.items.map(item => 'str' in item ? item.str : '').join(';'))))).join('\n')
          return parseCsv(`Компания;ИНН;Регион;Отрасль\n${text}`, file.name)
        }
      } catch { return [] }
      return []
    }))).flat()
    const next = [...uploadedCompanies, ...imported].filter((company, index, list) => list.findIndex(item => item.inn === company.inn) === index)
    setUploadedCompanies(next)
    localStorage.setItem('yufo-uploaded-companies', JSON.stringify(next))
    setImportStatus(imported.length ? `В каталог добавлено компаний: ${imported.length}. Источник сохранён в карточке каждой компании.` : 'Не удалось найти строки компаний. Проверьте заголовки: Компания, ИНН, Регион, Отрасль.')
    if (imported.length) addHistory('Импорт компаний', `${imported.length} из ${files.map(file => file.name).join(', ')}`)
    event.target.value = ''
  }
  const handleWebsite = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const website = String(form.get('website') || '').trim()
    if (!website) return
    setImportStatus(`Сайт принят в обработку: ${website}`)
    addHistory('Сайт добавлен', website)
    event.currentTarget.reset()
  }
  const [compareIds, setCompareIds] = useState<string[]>([])
  const groupCompanies = filteredCompanies.filter((c: typeof companies[number]) => companyGroup === 'Все компании' || (companyGroup === 'Крупные предприятия' ? c.revenueMillions >= 1000 : c.revenueMillions < 1000))
  const comparison = groupCompanies.filter((company: typeof companies[number]) => compareIds.includes(company.inn)).slice(0, 3)
  const exportRows = groupCompanies.map((c: typeof companies[number]) => ({ Компания: c.name, ИНН: c.inn, Сегмент: c.revenueMillions >= 1000 ? 'Крупное предприятие' : 'ИП / малый и средний бизнес', Отрасль: c.industry, Регион: c.region, Статус: c.status, Бюджет: c.budget, Направленность: c.direction, Цель: c.goal, Маржинальность: c.margin, Выручка: c.revenue, Рост: c.growth, Потенциал: c.potential }))
  return <>
    <div className="filter-bar company-toolbar"><div className="search-field"><Search size={17} /><input placeholder="Поиск компании или ИНН" aria-label="Поиск компании или ИНН" value={search} onChange={e => setSearch(e.target.value)} /></div><select aria-label="Регион ЮФО" value={region} onChange={e => setRegion(e.target.value)}><option>ЮФО</option>{yufoRegions.map(item => <option key={item}>{item}</option>)}</select><select aria-label="Отрасль" value={industry} onChange={e => setIndustry(e.target.value)}><option>Все отрасли</option><option>Промышленность</option><option>Телеком</option><option>Энергетика</option><option>Ритейл</option><option>Логистика</option><option>АПК</option></select><button className="button secondary" onClick={() => exportRows.length && exportExcel(exportRows, 'kompanii-yufo.xlsx')}><Download size={16} /> Экспорт списка</button></div>
    <section className="panel company-import-panel"><div className="panel-title"><div><h2>Добавить данные компании</h2><p className="table-subtitle">Импортируйте PDF, XLS, XLSX или CSV для последующей работы с каталогом. Данные из импорта не попадают на радар.</p></div><FileText size={18} /></div><div className="import-actions"><label className="button secondary upload-button"><Download size={16} /> Выбрать файлы<input type="file" hidden multiple accept=".pdf,.xls,.xlsx,.csv" onChange={handleFiles} /></label><form className="website-form" onSubmit={handleWebsite}><input name="website" type="url" placeholder="https://сайт-компании.ru" aria-label="Сайт компании" /><button className="button primary" type="submit">Принять сайт</button></form></div>{importStatus && <p className="import-status" role="status">{importStatus}</p>}</section>
    <div className="company-groups" role="tablist" aria-label="Сегмент компаний"><button className={companyGroup === 'Все компании' ? 'active' : ''} onClick={() => setCompanyGroup('Все компании')}>Все компании <b>{filteredCompanies.length}</b></button><button className={companyGroup === 'Крупные предприятия' ? 'active' : ''} onClick={() => setCompanyGroup('Крупные предприятия')}>Крупные предприятия <b>{filteredCompanies.filter((c: typeof companies[number]) => c.revenueMillions >= 1000).length}</b></button><button className={companyGroup === 'ИП и МСБ' ? 'active' : ''} onClick={() => setCompanyGroup('ИП и МСБ')}>ИП и малый и средний бизнес <b>{filteredCompanies.filter((c: typeof companies[number]) => c.revenueMillions < 1000).length}</b></button></div>
    <div className="company-summary"><div><span>Найдено компаний</span><strong>{groupCompanies.length}</strong></div><div><span>Крупные предприятия</span><strong>{filteredCompanies.filter((c: typeof companies[number]) => c.revenueMillions >= 1000).length}</strong></div><div><span>ИП и МСБ</span><strong>{filteredCompanies.filter((c: typeof companies[number]) => c.revenueMillions < 1000).length}</strong></div><div><span>ЮФО · выборка</span><strong>Реестр ФНС</strong></div></div>
    {comparison.length > 0 && <section className="panel comparison-panel"><div className="panel-title"><div><h2>Сравнение компаний</h2><p className="table-subtitle">Выбрано: {comparison.length} из 3. Сравните потенциал и условия перед расчётом.</p></div><button className="text-button" onClick={() => setCompareIds([])}>Очистить</button></div><div className="comparison-grid">{comparison.map((company: typeof companies[number]) => <div className="comparison-card" key={company.inn}><strong>{company.name}</strong><span>{company.region} · {company.industry}</span><b>{company.potential} <small>потенциал</small></b><button className="button primary" onClick={() => setSelectedCompany(company)}>Открыть в калькуляторе</button></div>)}</div></section>}
    <section className="panel companies-panel"><div className="panel-title"><div><h2>{companyGroup === 'Все компании' ? 'Компании и предприятия ЮФО' : companyGroup}</h2><p className="table-subtitle">Данные для ознакомления и выгрузки в Excel</p></div><span className="demo-pill">{groupCompanies.length} записей</span></div><div className="companies-table-wrap"><table className="companies-table"><thead><tr><th>Компания</th><th>ИНН</th><th>Сегмент</th><th>Отрасль</th><th>Регион</th><th>Источник</th><th>Бюджет</th><th>Рост</th><th>Маржинальность</th><th>Потенциал</th></tr></thead><tbody>{groupCompanies.map((c: typeof companies[number]) => <tr key={c.inn} className="company-row" onClick={() => setSelectedCompany(c)}><td><button className="company-name-button" type="button" onClick={() => setSelectedCompany(c)}><strong>{c.name}</strong><span>{c.direction}</span></button></td><td className="mono">{c.inn}</td><td>{c.revenueMillions >= 1000 ? 'Крупное предприятие' : 'ИП / МСБ'}</td><td>{c.industry}</td><td>{c.region}</td><td className="file-source">{(c as { sourceFile?: string }).sourceFile ?? 'Реестр ЮФО'}</td><td>{c.budget}</td><td className="growth">{c.growth}</td><td>{c.margin}</td><td><span className="potential-pill">{c.potential}</span><button className="table-link" onClick={(event) => { event.stopPropagation(); setSelectedCompany(c) }}>В работу</button><button className="table-link company-export-link" onClick={(event) => { event.stopPropagation(); exportCompany(c) }}><Download size={12} /> Excel</button><button className="table-link" onClick={(event) => { event.stopPropagation(); setCompareIds((current: string[]) => current.includes(c.inn) ? current.filter(id => id !== c.inn) : current.length < 3 ? [...current, c.inn] : current) }}>{compareIds.includes(c.inn) ? 'Убрать' : 'Сравнить'}</button></td></tr>)}{groupCompanies.length === 0 && <tr><td colSpan={10} className="empty-state">По заданным параметрам компании не найдены</td></tr>}</tbody></table></div></section>
  </>
}

function Navigator({ setModule }: { setModule: (m: Module) => void }) {
  const [query, setQuery] = useState('')
  const [stage, setStage] = useState('Все стадии')
  const [region, setRegion] = useState('ЮФО')
  const [focus, setFocus] = useState<'all' | 'priority' | 'next'>('all')
  const [plan, setPlan] = useState<string[]>([])
  const filtered = projects.filter(project => (stage === 'Все стадии' || project.stage === stage) && (region === 'ЮФО' || project.region === region) && (!query || `${project.name} ${project.investor} ${project.need}`.toLowerCase().includes(query.toLowerCase())) && (focus === 'all' || focus === 'priority' && project.score >= 80 || focus === 'next' && project.stage !== 'Запуск'))
  const togglePlan = (name: string) => setPlan(current => current.includes(name) ? current.filter(item => item !== name) : [...current, name])
  return <>
    <section className="navigator-intro"><div><p className="eyebrow">СИСТЕМА ПРИНЯТИЯ РЕШЕНИЙ</p><h2>Инвестиционный навигатор</h2><p>Переводит реестр проектов в последовательность действий: найти возможность, определить приоритет, сформировать план проработки и передать проект в калькулятор сделки.</p></div><div className="navigator-stepper"><span className="active">1 Поиск</span><span>2 Приоритет</span><span>3 Проработка</span><span>4 Решение</span></div></section>
    <div className="navigator-workbar"><strong>{filtered.length} проектов в рабочем наборе</strong><div><button className={focus === 'all' ? 'active' : ''} onClick={() => setFocus('all')}>Все</button><button className={focus === 'priority' ? 'active' : ''} onClick={() => setFocus('priority')}>Приоритетные</button><button className={focus === 'next' ? 'active' : ''} onClick={() => setFocus('next')}>Требуют действия</button></div><span>В плане проработки: {plan.length}</span></div>
    <div className="filter-bar"><div className="search-field"><Search size={17} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Поиск проекта, инициатора или отрасли" /></div><select value={stage} onChange={event => setStage(event.target.value)}><option>Все стадии</option><option>Проектирование</option><option>Строительство</option><option>Запуск</option></select><select value={region} onChange={event => setRegion(event.target.value)} aria-label="Регион ЮФО"><option>ЮФО</option>{yufoRegions.map(item => <option key={item}>{item}</option>)}</select></div>
    <div className="navigator-grid"><section className="panel project-list"><PanelTitle title="Рабочий список проектов" action="Сортировка: потенциал" />{filtered.map(p => <div className="project-card" key={p.name}><div className="project-card-top"><span className={`stage ${p.stage === 'Запуск' ? 'launch' : p.stage === 'Строительство' ? 'build' : 'plan'}`}>{p.stage}</span><span className="project-score">{p.score} <small>потенциал</small></span></div><h3>{p.name}</h3><p>{p.investor} · {p.region}</p><div className="project-meta"><span><strong>{p.budget}</strong><small>бюджет</small></span><span><strong>{p.date}</strong><small>плановый запуск</small></span><span><strong>{p.need}</strong><small>выявленные потребности</small></span></div><div className="navigator-actions"><button className="text-button" onClick={() => togglePlan(p.name)}>{plan.includes(p.name) ? 'Убрать из плана' : 'Включить в план'}</button><button className="text-button" onClick={() => setModule('calculator')}>Передать в калькулятор →</button></div></div>)}</section><aside className="navigator-side"><section className="panel"><PanelTitle title="Следующее действие" action="Регламент" /><div className="next-action"><span>Этап 3</span><strong>{plan.length ? 'Провести экономическую проработку' : 'Сформировать рабочий набор'}</strong><p>{plan.length ? `В плане ${plan.length} проект${plan.length === 1 ? '' : 'а'}. Передайте каждый проект в калькулятор и зафиксируйте бюджет, срок и маржинальность.` : 'Отберите приоритетные проекты по потенциалу и добавьте их в план проработки.'}</p><button className="button primary" onClick={() => plan.length ? setModule('calculator') : setFocus('priority')}>{plan.length ? 'Начать проработку' : 'Показать приоритетные'}</button></div></section><section className="panel navigator-method"><PanelTitle title="Логика навигатора" action="4 этапа" /><ol><li>Поиск и фильтрация</li><li>Приоритизация по потенциалу и сроку</li><li>Экономическая проверка в калькуляторе</li><li>Подготовка решения и сравнение</li></ol></section></aside></div>
  </>
}


function CalculatorModule({ scenario, setScenario, objects, setObjects, margin, setMargin, cost, setCost, totalCost, salePrice, profit, selectedCompany, onExport }: any) { return <><div className="calculator-tabs"><button className="active">Новый расчёт</button><button>История расчётов <span>12</span></button><button>Аналоги</button><button className="button secondary" onClick={onExport}><Download size={15} /> Экспорт результата</button></div><div className="calculator-layout"><section className="panel calculator-form"><div className="panel-title"><h2>Параметры проекта</h2></div><div className="form-section"><p className="form-label">Связанный проект</p><div className="selected-project"><div className="selected-icon"><BriefcaseBusiness size={17} /></div><div><strong>{selectedCompany?.name ?? 'Производственный кластер ЮФО'}</strong><span>{selectedCompany ? `${selectedCompany.region} · ${selectedCompany.industry} · ИНН ${selectedCompany.inn}` : 'ЮФО · строительство'}</span></div><button>Изменить</button></div></div><div className="form-grid"><label>Тип проекта<select><option>ИТ-инфраструктура площадки</option><option>Корпоративная сеть</option><option>Безопасность объекта</option></select></label><label>Масштаб проекта<select><option>Крупный</option><option>Средний</option><option>Малый</option></select></label><label>Количество объектов<input type="number" min="1" value={objects} onChange={e => setObjects(Math.max(1, Number(e.target.value)))} /></label><label>Срок реализации<select><option>12 месяцев</option><option>18 месяцев</option><option>24 месяца</option></select></label><label>Базовая стоимость объекта, млн ₽<input type="number" min="0" step="0.1" value={cost} onChange={e => setCost(Math.max(0, Number(e.target.value)))} /></label><label>Желаемая маржинальность, %<input type="number" min="0" value={margin} onChange={e => setMargin(Math.max(0, Number(e.target.value)))} /></label></div><div className="coefficient-box"><div><strong>Коэффициенты расчёта</strong><span>Показываемые значения можно изменить</span></div><div className="coefficient-row"><label>Региональный <input defaultValue="1,08" /></label><label>Срочность <input defaultValue="1,00" /></label><label>Сложность <input defaultValue="1,12" /></label></div></div><div className="form-actions"><button className="button secondary">Сбросить</button><button className="button primary"><Calculator size={16} /> Пересчитать</button></div></section><section className="panel result-panel"><div className="panel-title"><h2>Результат оценки</h2><span className="result-date">24.10.2026</span></div><div className="scenario-toggle">{['Экономичный', 'Базовый', 'Расширенный'].map(s => <button key={s} className={scenario === s ? 'active' : ''} onClick={() => setScenario(s)}>{s}</button>)}</div><div className="result-main"><span>Рекомендуемая цена продажи</span><strong>₽ {salePrice.toFixed(1)} млн</strong><small>диапазон ₽ {(totalCost * .86).toFixed(1)} — ₽ {(totalCost * 1.24).toFixed(1)} млн</small></div><div className="result-metrics"><div><span>Себестоимость</span><strong>₽ {totalCost.toFixed(1)} млн</strong></div><div><span>Валовая прибыль</span><strong className="growth">₽ {profit.toFixed(1)} млн</strong></div><div><span>Маржинальность</span><strong>{margin}%</strong></div></div><div className="cost-bars"><p>Структура себестоимости</p><div><span>Оборудование <b>52%</b></span><i><em style={{width:'52%'}} /></i></div><div><span>Работы <b>31%</b></span><i><em style={{width:'31%'}} /></i></div><div><span>ПО и прочее <b>17%</b></span><i><em style={{width:'17%'}} /></i></div></div><div className="analogs"><div><strong>3</strong><span>похожих аналога</span></div><div><strong>78%</strong><span>среднее сходство</span></div><button className="text-button">Сравнить →</button></div><button className="button primary full-button"><FileText size={16} /> Создать коммерческое предложение</button></section></div><div className="assumption-note"><CircleHelp size={16} /><span><strong>Важно:</strong> расчёт основан на демонстрационных аналогах и открытых коэффициентах. Это ориентир для предварительной оценки, не утверждённая методика и не коммерческое предложение.</span></div></> }
