'use client'

import { useEffect, useRef } from 'react'
import 'leaflet/dist/leaflet.css'

const points = [
  { name: 'Краснодар', lat: 45.0355, lng: 38.9753, count: 9 },
  { name: 'Сочи', lat: 43.6028, lng: 39.7342, count: 7 },
  { name: 'Новороссийск', lat: 44.7239, lng: 37.7689, count: 6 },
  { name: 'Анапа', lat: 44.895, lng: 37.3167, count: 4 },
  { name: 'Геленджик', lat: 44.5681, lng: 38.0771, count: 3 },
  { name: 'Армавир', lat: 45.0014, lng: 41.1234, count: 3 },
  { name: 'Туапсе', lat: 44.1056, lng: 39.0736, count: 2 },
  { name: 'Ростов-на-Дону', lat: 47.2357, lng: 39.7015, count: 8 },
  { name: 'Таганрог', lat: 47.2362, lng: 38.8969, count: 4 },
  { name: 'Шахты', lat: 47.7091, lng: 40.2159, count: 3 },
  { name: 'Волгодонск', lat: 47.5167, lng: 42.1514, count: 3 },
  { name: 'Новочеркасск', lat: 47.4111, lng: 40.0986, count: 2 },
  { name: 'Волгоград', lat: 48.708, lng: 44.5133, count: 7 },
  { name: 'Волжский', lat: 48.7858, lng: 44.7797, count: 4 },
  { name: 'Камышин', lat: 50.0836, lng: 45.4167, count: 2 },
  { name: 'Астрахань', lat: 46.3497, lng: 48.0408, count: 5 },
  { name: 'Элиста', lat: 46.3078, lng: 44.2558, count: 3 },
  { name: 'Майкоп', lat: 44.6098, lng: 40.1007, count: 3 },
  { name: 'Черкесск', lat: 44.2269, lng: 42.0468, count: 2 },
  { name: 'Ставрополь', lat: 45.0445, lng: 41.9691, count: 5 },
  { name: 'Пятигорск', lat: 44.0486, lng: 43.0594, count: 3 },
  { name: 'Кисловодск', lat: 43.905, lng: 42.7167, count: 2 },
  { name: 'Ессентуки', lat: 44.0444, lng: 42.8589, count: 2 },
  { name: 'Невинномысск', lat: 44.6225, lng: 41.9472, count: 2 },
  { name: 'Махачкала', lat: 42.9849, lng: 47.5047, count: 6 },
  { name: 'Дербент', lat: 42.067, lng: 48.2899, count: 3 },
  { name: 'Каспийск', lat: 42.8816, lng: 47.6392, count: 2 },
  { name: 'Назрань', lat: 43.2257, lng: 44.7646, count: 2 },
  { name: 'Владикавказ', lat: 43.0246, lng: 44.6818, count: 3 },
  { name: 'Грозный', lat: 43.3178, lng: 45.6987, count: 3 },
  { name: 'Нальчик', lat: 43.4846, lng: 43.6071, count: 2 },
  { name: 'Хасавюрт', lat: 43.2509, lng: 46.5877, count: 1 },
  { name: 'Батайск', lat: 47.1398, lng: 39.7518, count: 1 },
  { name: 'Ейск', lat: 46.7116, lng: 38.2765, count: 1 },
  { name: 'Кропоткин', lat: 45.4375, lng: 40.5756, count: 1 },
  { name: 'Белореченск', lat: 44.7653, lng: 39.8781, count: 1 },
  { name: 'Кизляр', lat: 43.8484, lng: 46.7235, count: 1 },
  { name: 'Будённовск', lat: 44.7847, lng: 44.1658, count: 1 },
  { name: 'Изобильный', lat: 45.3717, lng: 41.7086, count: 1 },
  { name: 'Лабинск', lat: 44.6353, lng: 40.7242, count: 1 },
  { name: 'Сальск', lat: 46.4752, lng: 41.5411, count: 1 },
  { name: 'Красный Сулин', lat: 47.8922, lng: 40.0704, count: 1 },
  { name: 'Симферополь', lat: 44.9521, lng: 34.1024, count: 4, company: 'АО «Крымский содовый завод»' },
  { name: 'Керчь', lat: 45.3562, lng: 36.467, count: 2, company: 'ООО «Залив»' },
  { name: 'Евпатория', lat: 45.1904, lng: 33.3669, count: 2, company: 'АО «Евпаторийский авиаремонтный завод»' },
  { name: 'Ялта', lat: 44.4952, lng: 34.1663, count: 1, company: 'АО «Интурист-Крым»' },
  { name: 'Севастополь', lat: 44.6167, lng: 33.5254, count: 3, company: 'АО «Севастопольский морской завод»' },
  { name: 'Краснодар', lat: 45.048, lng: 38.982, count: 1, company: 'АО «Тандер»' },
  { name: 'Краснодар', lat: 45.025, lng: 38.961, count: 1, company: 'АО «Краснодарский завод Нефтемаш»' },
  { name: 'Краснодар', lat: 45.061, lng: 38.948, count: 1, company: 'АО «Краснодарский завод РТИ»' },
  { name: 'Краснодар', lat: 45.014, lng: 39.031, count: 1, company: 'ООО «Группа компаний Агроплюс»' },
  { name: 'Ростов-на-Дону', lat: 47.251, lng: 39.689, count: 1, company: 'АО «Корпорация Глория Джинс»' },
  { name: 'Ростов-на-Дону', lat: 47.219, lng: 39.756, count: 1, company: 'ПАО «Россети Юг»' },
  { name: 'Ростов-на-Дону', lat: 47.266, lng: 39.716, count: 1, company: 'АО «Клевер»' },
  { name: 'Ростов-на-Дону', lat: 47.204, lng: 39.643, count: 1, company: 'ООО «Ростовский прессово-раскройный завод»' },
  { name: 'Ростов-на-Дону', lat: 47.229, lng: 39.782, count: 1, company: 'ОАО «Завод РТИ»' },
  { name: 'Азов', lat: 47.112, lng: 39.423, count: 1, company: 'ООО «Азовтеплоэнерго»' },
  { name: 'Азов', lat: 47.095, lng: 39.414, count: 1, company: 'ООО «РЗСП Термакс»' },
  { name: 'Ростов-на-Дону', lat: 47.242, lng: 39.671, count: 1, company: 'ООО «Ростовский трубопрофильный завод»' },
  { name: 'Краснодар', lat: 45.073, lng: 39.012, count: 1, company: 'ООО «НК Приазовнефть»' },
  { name: 'Краснодар', lat: 45.033, lng: 39.004, count: 1, company: 'АО «ИКТ»' },
  { name: 'Волгоград', lat: 48.724, lng: 44.492, count: 1, company: 'ООО «Астерра»' },
  { name: 'Волгоград', lat: 48.692, lng: 44.531, count: 1, company: 'ООО «Астра»' },
  { name: 'Волгоград', lat: 48.735, lng: 44.467, count: 1, company: 'ООО «Астратех»' },
  { name: 'Волгоград', lat: 48.681, lng: 44.559, count: 1, company: 'АО «Волгоградский областной энергетический комплекс»' },
  { name: 'Волжский', lat: 48.797, lng: 44.769, count: 1, company: 'ООО «Волжаночка»' },
  { name: 'Астрахань', lat: 46.365, lng: 48.025, count: 1, company: 'ООО «Астхимчистка»' },
  { name: 'Астрахань', lat: 46.341, lng: 48.067, count: 1, company: 'ООО «АСК Волга-Град»' },
  { name: 'Астрахань', lat: 46.377, lng: 48.011, count: 1, company: 'ООО «Энергопром»' },
  { name: 'Астрахань', lat: 46.329, lng: 48.043, count: 1, company: 'МУП «Горэлектросеть»' },
  { name: 'Астрахань', lat: 46.354, lng: 48.084, count: 1, company: 'ООО «Астраханьагроимпорт»' },
  { name: 'Новороссийск', lat: 44.735, lng: 37.754, count: 1, company: 'ПАО «Новороссийский морской торговый порт»' },
  { name: 'Сочи', lat: 43.615, lng: 39.721, count: 1, company: 'АО «Сочи-Парк»' },
  { name: 'Таганрог', lat: 47.226, lng: 38.911, count: 1, company: 'ПАО «Таганрогский авиационный научно-технический комплекс имени Г. М. Бериева»' },
  { name: 'Волгодонск', lat: 47.503, lng: 42.164, count: 1, company: 'Атоммаш' },
  { name: 'Симферополь', lat: 44.968, lng: 34.089, count: 1, company: 'АО «Крымский содовый завод»' },
  { name: 'Керчь', lat: 45.367, lng: 36.454, count: 1, company: 'ООО «Залив»' },
]

const yufoRegionNames = ['Краснодарский край', 'Ростовская область', 'Волгоградская область', 'Астраханская область', 'Республика Адыгея', 'Республика Калмыкия', 'Республика Крым', 'г. Севастополь']

const regionCities: Record<string, string[]> = {
  'Краснодарский край': ['Краснодар', 'Сочи', 'Новороссийск', 'Анапа', 'Геленджик', 'Армавир', 'Туапсе', 'Батайск', 'Ейск', 'Кропоткин', 'Белореченск', 'Лабинск'],
  'Ростовская область': ['Ростов-на-Дону', 'Таганрог', 'Шахты', 'Волгодонск', 'Новочеркасск', 'Батайск', 'Сальск', 'Красный Сулин'],
  'Волгоградская область': ['Волгоград', 'Волжский', 'Камышин'],
  'Астраханская область': ['Астрахань'],
  'Республика Калмыкия': ['Элиста'],
  'Республика Адыгея': ['Майкоп'],
  'Республика Крым': ['Симферополь', 'Керчь', 'Евпатория', 'Ялта'],
  'г. Севастополь': ['Севастополь'],
  'Ставропольский край': ['Ставрополь', 'Пятигорск', 'Кисловодск', 'Ессентуки', 'Невинномысск', 'Будённовск', 'Изобильный'],
  'Республика Дагестан': ['Махачкала', 'Дербент', 'Каспийск', 'Хасавюрт', 'Кизляр'],
  'Кабардино-Балкарская Республика': ['Нальчик'],
  'Республика Северная Осетия — Алания': ['Владикавказ'],
  'Чеченская Республика': ['Грозный'],
  'Республика Ингушетия': ['Назрань'],
  'Карачаево-Черкесская Республика': ['Черкесск'],
}

export function LeafletPresenceMap({ region = 'ЮФО' }: { region?: string }) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let map: import('leaflet').Map | undefined
    let disposed = false

    async function loadMap() {
      if (!containerRef.current) return
      const leaflet = await import('leaflet')
      if (disposed || !containerRef.current) return
      map = leaflet.map(containerRef.current, { scrollWheelZoom: false, zoomControl: true, attributionControl: true }).setView([46.1, 41.4], 6.8)
      leaflet.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 18,
      }).addTo(map)

      const yufoCities = yufoRegionNames.flatMap(name => regionCities[name] ?? [])
      const visibleCities = new Set(region === 'ЮФО' ? yufoCities : regionCities[region] ?? [])
      points.filter(point => visibleCities.has(point.name)).forEach((point) => {
        const intensity = point.count / 9
        const color = intensity >= 0.75 ? '#6f2dbd' : intensity >= 0.45 ? '#b66dca' : '#e3a24a'
        leaflet.circle([point.lat, point.lng], {
          radius: 24000 + point.count * 5200,
          color,
          fillColor: color,
          fillOpacity: 0.18 + intensity * 0.2,
          weight: 0,
        }).addTo(map!)
        leaflet.circleMarker([point.lat, point.lng], {
          radius: Math.max(6, Math.min(16, 5 + point.count * 0.72)),
          color: '#fff1d6',
          fillColor: color,
          fillOpacity: 0.94,
          weight: 1.5,
        }).addTo(map!).bindPopup(`<strong>${point.name}</strong>${point.company ? `<br/>${point.company}` : ''}<br/>${point.count} потенциальных компаний<br/><small>ЮФО · Реестр ФНС России / ЕРМСП</small>`)
      })
    }

    loadMap()
    return () => { disposed = true; map?.remove() }
  }, [region])

  return <div ref={containerRef} className="leaflet-presence-map" aria-label="Тепловая карта 42 потенциальных крупных компаний Южного федерального округа" />
}
